# Bolt Mobile SDK

The lib directory contains the most current variant of the SDK's .aar file, docs houses the
generated Javadoc files, and sample_app is representative of how the .aar could be utilized.

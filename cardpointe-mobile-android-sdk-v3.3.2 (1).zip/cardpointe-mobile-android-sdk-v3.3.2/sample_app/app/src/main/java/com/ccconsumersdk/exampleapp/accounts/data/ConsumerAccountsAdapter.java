package com.ccconsumersdk.exampleapp.accounts.data;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bolt.consumersdk.domain.CCConsumerAccount;
import com.ccconsumersdk.exampleapp.R;

import java.util.ArrayList;
import java.util.List;

public class ConsumerAccountsAdapter extends RecyclerView.Adapter<ConsumerAccountsAdapter.ViewHolder> {

    private final AccountListener mListener;
    private List<CCConsumerAccount> mAccounts = new ArrayList<>();

    public ConsumerAccountsAdapter(AccountListener listener) {
        mListener = listener;
    }

    @Override
    public ConsumerAccountsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.account_list_item_example, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        CCConsumerAccount accountItem = mAccounts.get(position);
        holder.bind(accountItem, mListener);

        String accountInfo = accountItem.getAccountType().toString() + " " + accountItem.getLast4();
        if (accountItem.isDefaultAccount()) {
            holder.mDefault.setVisibility(View.VISIBLE);
        } else {
            holder.mDefault.setVisibility(View.GONE);
        }
        holder.mAccountName.setText(accountInfo);
    }

    @Override
    public int getItemCount() {
        return mAccounts.size();
    }

    public void addAccountItems(ArrayList<CCConsumerAccount> items) {
        mAccounts.addAll(items);
    }

    public void clear() {
        mAccounts.clear();
    }

    public interface AccountListener {
        void onAccountItemClick(CCConsumerAccount account);

        void onAccountItemLongClick(CCConsumerAccount account);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView mAccountName;
        private TextView mDefault;

        private ViewHolder(View view) {
            super(view);
            mAccountName = (TextView)view.findViewById(R.id.text_view_account_info);
            mDefault = (TextView)view.findViewById(R.id.text_view_account_default);
        }

        private void bind(final CCConsumerAccount consumerAccount,
                final AccountListener listener) {
            this.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onAccountItemClick(consumerAccount);
                }
            });
            this.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    listener.onAccountItemLongClick(consumerAccount);
                    return true;
                }
            });
        }
    }
}

package com.ccconsumersdk.exampleapp.editAccount;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.SwitchCompat;
import android.view.View;

import com.bolt.consumersdk.CCConsumerApiBridgeCallbacks;
import com.bolt.consumersdk.domain.CCConsumerAccount;
import com.bolt.consumersdk.domain.response.CCConsumerApiBridgeResponse;
import com.ccconsumersdk.apicommunication.ApiBridgeImpl;
import com.ccconsumersdk.exampleapp.BaseActivity;
import com.ccconsumersdk.exampleapp.R;
import com.ccconsumersdk.exampleapp.accounts.AccountsActivity;

public class EditAccountActivity extends BaseActivity {
    private ApiBridgeImpl mApiBridge;
    private SwitchCompat mDefaultAccountSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        setupToolBar();

        mDefaultAccountSwitch = (SwitchCompat)findViewById(R.id.switch_default_account);

        mApiBridge = new ApiBridgeImpl();

        final CCConsumerAccount editAccount = getIntent().getParcelableExtra(AccountsActivity.ACCOUNT_EDIT);

        if (editAccount != null) {
            mDefaultAccountSwitch.setChecked(editAccount.isDefaultAccount());
            // TODO: Populate Expiration Date as well
        }

        findViewById(R.id.button_save_card).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editAccount != null) {
                    editAccount.setDefaultAccount(mDefaultAccountSwitch.isChecked());
                    updateAccount(editAccount);
                }
            }
        });
    }

    private void updateAccount(CCConsumerAccount account) {
        mApiBridge.updateAccount(account, new CCConsumerApiBridgeCallbacks() {
            @Override
            public void onApiResponse(@NonNull CCConsumerApiBridgeResponse response) {
                if (response.getCCConsumerError() != null) {
                    showErrorDialog(response.getCCConsumerError().getResponseMessage());
                } else {
                    finish();
                }
            }
        });
    }
}

package com.ccconsumersdk.exampleapp;

import androidx.annotation.NonNull;
import com.google.android.material.snackbar.Snackbar;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bolt.consumersdk.permissions.IPermissionBaseActivity;
import com.bolt.consumersdk.permissions.IPermissionCallback;
import com.ccconsumersdk.exampleapp.components.SpinningDialogFragment;

import java.util.HashMap;
import java.util.Map;

public abstract class BaseActivity extends AppCompatActivity implements IPermissionBaseActivity {
    /**
     * Callbacks that will be executed when onRequestPermissionsResult is called
     */
    private final Map<Integer, IPermissionCallback> permissionCallbacks = new HashMap<>();

    private SpinningDialogFragment mSpinningDialogFragment;

    protected void showProgressDialog() {
        if (getSupportFragmentManager().findFragmentByTag(SpinningDialogFragment.TAG) == null) {
            mSpinningDialogFragment = SpinningDialogFragment.newInstance();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.add(mSpinningDialogFragment, SpinningDialogFragment.TAG);
            transaction.commitAllowingStateLoss();
        }
    }

    protected void updateProgressDialogCompletionPercentage(int progress) {
        if (mSpinningDialogFragment != null) {
            mSpinningDialogFragment.setProgress(progress);
        }
    }

    protected void setupToolBar() {
        Toolbar toolbar = (Toolbar)findViewById(R.id.tool_bar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (!(this instanceof MainActivity) && getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }
    }

    protected void dismissProgressDialog() {
        SpinningDialogFragment fragment =
                (SpinningDialogFragment)getSupportFragmentManager().findFragmentByTag(SpinningDialogFragment.TAG);

        if (fragment != null) {
            getSupportFragmentManager().beginTransaction().remove(fragment).commitAllowingStateLoss();
        }
    }

    protected void showErrorDialog(String errorMessage) {
        new AlertDialog.Builder(this).setTitle(getString(R.string.error)).setMessage(errorMessage)
                .setNeutralButton(android.R.string.ok, null)
                .show();
    }

    protected void showMessageDialog(String message) {
        new AlertDialog.Builder(this).setTitle("").setMessage(message)
                .setNeutralButton(android.R.string.ok, null)
                .show();
    }

    protected void showSnackBarMessage(String snackMessage) {
        Snackbar.make(findViewById(android.R.id.content), snackMessage, Snackbar.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        handleRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @NonNull
    @Override
    public Map<Integer, IPermissionCallback> getPermissionCallbacks() {
        return permissionCallbacks;
    }
}

package com.ccconsumersdk.exampleapp.idtech;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bolt.consumersdk.domain.CCConsumerAccount;
import com.bolt.consumersdk.domain.CCConsumerError;
import com.bolt.consumersdk.swiper.CCSwiperControllerFactory;
import com.bolt.consumersdk.swiper.DeviceState;
import com.bolt.consumersdk.swiper.SwiperController;
import com.bolt.consumersdk.swiper.SwiperControllerListener;
import com.bolt.consumersdk.swiper.SwiperControllerListenerStub;
import com.bolt.consumersdk.swiper.enums.CardProcessingType;
import com.bolt.consumersdk.swiper.enums.DeviceMessage;
import com.bolt.consumersdk.swiper.enums.SwiperCaptureMode;
import com.bolt.consumersdk.swiper.enums.SwiperError;
import com.bolt.consumersdk.utils.LogHelper;
import com.bolt.consumersdk.views.CCConsumerCreditCardNumberEditText;
import com.bolt.consumersdk.views.CCConsumerExpirationDateEditText;
import com.bolt.consumersdk.views.payment.components.ConsumerEditText;
import com.ccconsumersdk.exampleapp.BaseActivity;
import com.ccconsumersdk.exampleapp.R;

public class IDTechCardReaderActivity extends BaseActivity {
    private static final String TAG = IDTechCardReaderActivity.class.getSimpleName();

    private SwiperController swiperController;
    private String deviceAddress;

    private final SwiperControllerListener SWIPER_CONTROLLER_LISTENER = new SwiperControllerListenerStub() {
        @Override
        public void onTokenGenerated(CCConsumerAccount account, CCConsumerError error) {
            if (error != null) {
                updateLogs(error.getResponseMessage());
                setButtonEnabled(true, false);
                return;
            }

            updateLogs(getString(R.string.token_generated, account.getToken()));
            fillupCardDetails(account);
            setButtonEnabled(true, false);
        }

        @Override
        public void onStartTokenGeneration() {
            updateLogs("Completing transaction...");
            setButtonEnabled(false, false);
        }

        @Override
        public void onError(SwiperError swipeError) {
            updateLogs(swipeError.toString());
            setButtonEnabled(true, false);
        }

        @Override
        public void onSwiperReadyForCard(CardProcessingType cardProcessingType) {
            updateLogs(cardProcessingType.getMessage());
            setButtonEnabled(false, true);
        }

        @Override
        public void onSwiperConnected() {
            updateLogs("CONNECTED");
        }

        @Override
        public void onSwiperDisconnected() {
            updateLogs("DISCONNECTED");
        }

        @Override
        public void showDeviceMessage(@NonNull DeviceMessage deviceMessage, @NonNull DeviceState deviceState) {
            setButtonEnabled(false, deviceState.isCancellable());
            updateLogs(deviceMessage.getMessage());
        }

        @Override
        public void onDeviceConfigurationUpdate(String strUpdate) {
            LogHelper.write(TAG, strUpdate);
        }

        @Override
        public void onDeviceConfigurationProgressUpdate(double dProgress) {
            updateLogs("Configuration Progress: " + dProgress);
        }

        @Override
        public void onDeviceConfigurationComplete(boolean isUpdated) {
            updateLogs("Configuration Complete: " + isUpdated);
        }

        @Override
        public void onTimeout() {
            updateLogs("TIMEOUT");
            setButtonEnabled(true, false);
        }

        @Override
        public void onRemoveCardRequested() {
            updateLogs("REMOVE CARD REQUESTED");
        }

        @Override
        public void onCardRemoved() {
            updateLogs("CARD REMOVED");
            setButtonEnabled(true, false);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_idtech_card_reader);
        setupToolBar();

        Intent intent = getIntent();
        deviceAddress = intent.getStringExtra(IDTechActivity.IDTECH_DEVICE_ADDRESS);
        Log.d(TAG, "Device Address: " + deviceAddress);

        getCreditCardNumberField().setEnabled(false);
        getExpirationDateField().setEnabled(false);
        getCardHolderNameField().setEnabled(false);
        setStopTransactionEnabled(false);

        swiperController = new CCSwiperControllerFactory().create(IDTechCardReaderActivity.this,
                SWIPER_CONTROLLER_LISTENER, deviceAddress, false);
        swiperController.setDebugEnabled(true);
    }

    private void clearCardDetails() {
        getCreditCardNumberField().setText("");
        getExpirationDateField().setText("");
        getCardHolderNameField().setText("");
    }

    private void fillupCardDetails(CCConsumerAccount account) {
        getCreditCardNumberField().setText(account.getToken());
        getExpirationDateField().setText(account.getExpirationDate());
        getCardHolderNameField().setText(account.getName());
    }

    private CCConsumerCreditCardNumberEditText getCreditCardNumberField() {
        return findViewById(R.id.text_edit_credit_card_number);
    }

    private CCConsumerExpirationDateEditText getExpirationDateField() {
        return findViewById(R.id.text_edit_credit_card_expiration_date);
    }

    private ConsumerEditText getCardHolderNameField() {
        return findViewById(R.id.text_cardholder_name);
    }

    private void setButtonEnabled(boolean startEnabled, boolean stopEnabled) {
        setStartTransactionEnabled(startEnabled);
        setStopTransactionEnabled(stopEnabled);
    }

    private void setStartTransactionEnabled(boolean enabled) {
        setButtonEnabled(R.id.button_start_transaction, enabled);
    }

    private void setStopTransactionEnabled(boolean enabled) {
        setButtonEnabled(R.id.button_stop_transaction, enabled);
        setButtonEnabled(R.id.button_disconnect, enabled);
    }

    private void setButtonEnabled(int id, boolean enabled) {
        Button button = findViewById(id);
        button.setEnabled(enabled);
        button.setVisibility(enabled ? View.VISIBLE : View.INVISIBLE);
    }

    public void disconnect(View view) {
        Log.d(TAG, "Disconnect");
        updateLogs("DISCONNECT");
        setButtonEnabled(false, false);
        clearCardDetails();
        new Thread(() -> {
            swiperController.disconnect();
            new Handler(Looper.getMainLooper()).post(() ->
                    setButtonEnabled(true, false));
        }).start();
    }

    public void startTransaction(View view) {
        Log.d(TAG, "Start Transaction");
        updateLogs("START TRANSACTION");
        setButtonEnabled(false, true);
        clearCardDetails();

        new Thread(() ->
                swiperController.startTransaction(SwiperCaptureMode.SWIPE_TAP_INSERT, 0.01)
        ).start();
    }

    public void stopTransaction(View view) {
        Log.d(TAG, "Stop Transaction");
        updateLogs("STOP TRANSACTION");
        setButtonEnabled(false, false);
        clearCardDetails();
        new Thread(() -> {
            swiperController.stopTransaction();
            new Handler(Looper.getMainLooper()).post(() ->
                    setButtonEnabled(true, false));
        }).start();
    }

    private void updateLogs(String logs) {
        TextView logsTextView = findViewById(R.id.logsValue);
        logsTextView.setText(logs);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (swiperController != null) {
            swiperController.disconnect();
        }
    }
}

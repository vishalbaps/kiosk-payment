package com.ccconsumersdk.exampleapp;

import android.app.Application;

import com.bolt.consumersdk.CCConsumer;
import com.bolt.consumersdk.network.CCConsumerApi;

public class MainApp extends Application {

    public static CCConsumerApi getConsumerApi() {
        return CCConsumer.getInstance().getApi();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        setupConsumerApi();
    }

    /**
     * Initial Configuration for Consumer Api
     */
    private void setupConsumerApi() {
        CCConsumer.getInstance().getApi().setEndPoint("https://qa.cardconnect.com");
        CCConsumer.getInstance().getApi().setDebugEnabled(true);
    }
}

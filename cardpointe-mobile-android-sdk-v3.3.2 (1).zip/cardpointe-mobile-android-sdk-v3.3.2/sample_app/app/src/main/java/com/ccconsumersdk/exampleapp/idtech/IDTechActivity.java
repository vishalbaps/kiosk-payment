package com.ccconsumersdk.exampleapp.idtech;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bolt.consumersdk.CCConsumer;
import com.bolt.consumersdk.listeners.BluetoothSearchResponseListener;
import com.bolt.consumersdk.permissions.CcPermissionGroup;
import com.bolt.consumersdk.permissions.PermissionUtils;
import com.ccconsumersdk.exampleapp.BaseActivity;
import com.ccconsumersdk.exampleapp.R;

public class IDTechActivity extends BaseActivity {

    private static final String TAG = IDTechActivity.class.getSimpleName();
    public static final String IDTECH_DEVICE_ADDRESS = "IDTECH_DEVICE_ADDRESS";

    // For faster testing, you may change the DEFAULT_DEVICE_ADDRESS to the Address of your Swiper device
    private static final String DEFAULT_DEVICE_ADDRESS = null;

    @Nullable
    private String deviceAddress;

    @Nullable
    private String deviceLabel;

    private AlertDialog deviceSetupDialog;

    private BluetoothSearchResponseListener BLUETOOTH_SEARCH_LISTENER = new BluetoothSearchResponseListener() {
        @Override
        public void onDeviceFound(final BluetoothDevice device) {
            deviceSetupDialog.dismiss();
            stopBluetoothDeviceSearch();

            new AlertDialog.Builder(IDTechActivity.this)
                    .setMessage("Found device " + device.getName())
                    .setCancelable(false)
                    .setNeutralButton(android.R.string.ok,
                            (dialog, which) -> {
                                updateDeviceValues(device.getName(), device.getAddress());
                                dialog.dismiss();
                            })
                    .show();
        }

        @Override
        public void onSearchCancelled() {
            // NOOP
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_idtech);
        setupToolBar();
        updateDeviceValues(DEFAULT_DEVICE_ADDRESS, DEFAULT_DEVICE_ADDRESS);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        CCConsumer.getInstance().getApi().stopBluetoothDeviceSearch();
    }

    private boolean isEmpty(String value) {
        return value == null || value.length() == 0;
    }

    private void updateDeviceValues(String deviceName, String deviceAddress) {
        boolean hasDeviceValue = !isEmpty(deviceAddress) && !isEmpty(deviceName);
        this.deviceLabel = deviceName;
        this.deviceAddress = deviceAddress;

        if (!hasDeviceValue) {
            this.deviceAddress = null;
            this.deviceLabel = getResources().getString(R.string.idtech_device_name_none);
        } else if (!deviceLabel.equals(deviceAddress)) {
            this.deviceLabel = deviceName + "\n(" + deviceAddress + ")";
        }

        TextView deviceNameTextView = findViewById(R.id.deviceNameValue);
        deviceNameTextView.setText(this.deviceLabel);

        setReadCardButtonEnabled(hasDeviceValue);
    }

    private void setReadCardButtonEnabled(boolean isEnabled) {
        Button readCardButton = findViewById(R.id.button_read_card);
        readCardButton.setEnabled(isEnabled);
        readCardButton.setVisibility(isEnabled ? View.VISIBLE : View.INVISIBLE);
    }

    public void startDeviceSetup(View view) {
        PermissionUtils.executeWithPermissions(this, CcPermissionGroup.BLUETOOTH, isPermissionGranted -> {
            if (isPermissionGranted) {
                doStartDeviceSetup();
            } else {
                this.showErrorDialog(getString(R.string.idtech_no_bluetooth_permissions));
            }
        });
    }

    private void doStartDeviceSetup() {
        Log.d(TAG, "Starting device setup...");
        final BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) {
            Log.w(TAG, "Bluetooth adapter is null. Cannot continue");
            showErrorDialog(getString(R.string.idtech_no_bluetooth_adapter));
            return;
        }

        deviceSetupDialog = new AlertDialog.Builder(IDTechActivity.this)
                .setMessage(R.string.common_dialog_searching)
                .setCancelable(false)
                .setNegativeButton(android.R.string.cancel, (dialog, which) -> {
                    stopBluetoothDeviceSearch();
                    updateDeviceValues(null, null);
                    dialog.dismiss();
                }).show();

        updateDeviceValues(null, null);
        bluetoothAdapter.enable();
        CCConsumer.getInstance().getApi().startBluetoothDeviceSearch(BLUETOOTH_SEARCH_LISTENER,
                IDTechActivity.this, true);
    }

    private void stopBluetoothDeviceSearch() {
        CCConsumer.getInstance().getApi().stopBluetoothDeviceSearch();
    }

    public void readCard(View view) {
        Log.d(TAG, "Reading card...");

        if (this.deviceAddress == null) {
            new AlertDialog.Builder(IDTechActivity.this)
                    .setMessage(R.string.idtech_invalid_device)
                    .setCancelable(true)
                    .setNeutralButton(android.R.string.ok, (dialog, which) -> {
                        dialog.dismiss();
                    })
                    .show();
            Log.d(TAG, "Cannot read card. Device is invalid.");
            return;
        }

        Intent intent = new Intent(this, IDTechCardReaderActivity.class);
        intent.putExtra(IDTECH_DEVICE_ADDRESS, this.deviceAddress);
        startActivity(intent);
    }
}
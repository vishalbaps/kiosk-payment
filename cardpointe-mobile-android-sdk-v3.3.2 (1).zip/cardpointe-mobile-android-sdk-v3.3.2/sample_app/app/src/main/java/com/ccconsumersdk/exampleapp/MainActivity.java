package com.ccconsumersdk.exampleapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import com.bolt.consumersdk.domain.CCConsumerAccount;
import com.bolt.consumersdk.views.payment.accounts.PaymentAccountsActivity;
import com.ccconsumersdk.apicommunication.ApiBridgeImpl;
import com.ccconsumersdk.exampleapp.customflow.CustomFlowActivity;
import com.ccconsumersdk.exampleapp.idtech.IDTechActivity;


public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setupToolBar();
    }

    public void startCustomFlowActivity(View view) {
        Intent intent = new Intent(this, CustomFlowActivity.class);
        startActivity(intent);
    }

    public void startIDTechFlowActivity(View view) {
        Intent intent = new Intent(this, IDTechActivity.class);
        startActivity(intent);
    }

    public void startIntegratedCustomFlowActivity(View view) {
        //Launch Checkout process from example app a CCConsumerApiBridge implementation needs to be provided
        ApiBridgeImpl apiBridgeImpl = new ApiBridgeImpl();
        Intent intent = new Intent(this, PaymentAccountsActivity.class);
        intent.putExtra(PaymentAccountsActivity.API_BRIDGE_IMPL_KEY, apiBridgeImpl);

        startActivityForResult(intent, PaymentAccountsActivity.PAYMENT_ACTIVITY_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //Get Account selected by integrated UI flow
        if (requestCode == PaymentAccountsActivity.PAYMENT_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {

                //Example of general account selected
                CCConsumerAccount selectedAccount =
                        data.getParcelableExtra(PaymentAccountsActivity.PAYMENT_ACTIVITY_ACCOUNT_SELECTED);
                showSnackBarMessage(getString(R.string.selected_account_text_format, selectedAccount.getAccountType()
                        .toString(), selectedAccount.getLast4()));

        }
    }
}

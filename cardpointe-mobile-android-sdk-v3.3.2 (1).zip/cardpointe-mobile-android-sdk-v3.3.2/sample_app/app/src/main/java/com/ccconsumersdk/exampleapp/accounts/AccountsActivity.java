package com.ccconsumersdk.exampleapp.accounts;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.bolt.consumersdk.CCConsumerApiBridgeCallbacks;
import com.bolt.consumersdk.domain.CCConsumerAccount;
import com.bolt.consumersdk.domain.response.CCConsumerApiBridgeGetAccountsResponse;
import com.bolt.consumersdk.domain.response.CCConsumerApiBridgeResponse;
import com.ccconsumersdk.apicommunication.ApiBridgeImpl;
import com.ccconsumersdk.exampleapp.BaseActivity;
import com.ccconsumersdk.exampleapp.R;
import com.ccconsumersdk.exampleapp.accounts.data.ConsumerAccountsAdapter;
import com.ccconsumersdk.exampleapp.customflow.CustomFlowActivity;
import com.ccconsumersdk.exampleapp.editAccount.EditAccountActivity;

import java.util.ArrayList;

public class AccountsActivity extends BaseActivity {
    public static final String ACCOUNT_EDIT = "account_edit";
    private static final int EDIT_ACCOUNT_REQUEST_CODE = 2;
    private static final int NEW_ACCOUNT_REQUEST_CODE = 1;
    private ApiBridgeImpl mApiBridge;
    private ConsumerAccountsAdapter mAccountListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accounts_example);
        setupToolBar();

        findViewById(R.id.button_add_new_card).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomFlowActivity();
            }
        });

        mApiBridge = new ApiBridgeImpl();
        mAccountListAdapter = new ConsumerAccountsAdapter(new ConsumerAccountsAdapter.AccountListener() {
            @Override
            public void onAccountItemClick(CCConsumerAccount account) {
                showEditAccountActivity(account);
            }

            @Override
            public void onAccountItemLongClick(CCConsumerAccount account) {
                confirmDeleteAccount(account);
            }
        });

        final LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        RecyclerView locationsRecyclerView = (RecyclerView)findViewById(R.id.recycler_view_accounts);
        locationsRecyclerView.setHasFixedSize(true);
        locationsRecyclerView.setLayoutManager(layoutManager);
        locationsRecyclerView.setAdapter(mAccountListAdapter);

        loadAccounts();
    }

    private void loadAccounts() {
        mApiBridge.getAccounts(new CCConsumerApiBridgeCallbacks() {
            @Override
            public void onApiResponse(@NonNull CCConsumerApiBridgeResponse response) {
                if (response.getCCConsumerError() != null) {
                    showErrorDialog(response.getCCConsumerError().getResponseMessage());
                } else {
                    updateListView(((CCConsumerApiBridgeGetAccountsResponse)response).getCCConsumerAccounts());
                }
            }
        });
    }

    private void deleteAccount(CCConsumerAccount accountToDelete) {
        mApiBridge.deleteCustomerAccount(accountToDelete, new CCConsumerApiBridgeCallbacks() {
            @Override
            public void onApiResponse(@NonNull CCConsumerApiBridgeResponse response) {
                if (response.getCCConsumerError() != null) {
                    showErrorDialog(response.getCCConsumerError().getResponseMessage());
                } else {
                    loadAccounts();
                }
            }
        });
    }

    private void updateListView(ArrayList<CCConsumerAccount> list) {
        if (mAccountListAdapter != null) {
            mAccountListAdapter.clear();
            mAccountListAdapter.addAccountItems(list);
            mAccountListAdapter.notifyDataSetChanged();
        }
    }

    private void showCustomFlowActivity() {
        Intent intent = new Intent(this, CustomFlowActivity.class);
        startActivityForResult(intent, NEW_ACCOUNT_REQUEST_CODE);
    }

    private void showEditAccountActivity(CCConsumerAccount account) {
        Intent intent = new Intent(this, EditAccountActivity.class);
        intent.putExtra(ACCOUNT_EDIT, account);
        startActivityForResult(intent, EDIT_ACCOUNT_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        loadAccounts();
    }

    private void confirmDeleteAccount(final CCConsumerAccount accountToDelete) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.confirm_delete)
                .setMessage(R.string.delete_account_message)
                .setCancelable(false)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        deleteAccount(accountToDelete);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}

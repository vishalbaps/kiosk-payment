package com.ccconsumersdk.apicommunication;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;

import com.cardconnect.android.sdk.CCConfiguration;
import com.cardconnect.android.sdk.CardConnect;
import com.cardconnect.android.sdk.model.CardConnectObject;
import com.cardconnect.android.sdk.model.enums.ResponseStatus;
import com.cardconnect.android.sdk.model.request.ProfileCreateUpdateRequest;
import com.cardconnect.android.sdk.model.response.Profile.ProfileCreateUpdateResponse;
import com.cardconnect.android.sdk.model.response.Profile.ProfileDeleteResponse;
import com.cardconnect.android.sdk.model.response.Profile.ProfileGetResponse;
import com.cardconnect.android.sdk.model.response.Profile.ProfilesResponse;
import com.cardconnect.android.sdk.rest.CardConnectExceptions.CardConnectError;
import com.cardconnect.android.sdk.rest.RestApiDelegate;

import com.bolt.consumersdk.CCConsumerApiBridgeCallbacks;
import com.bolt.consumersdk.CCConsumerApiBridge;
import com.bolt.consumersdk.domain.CCConsumerAccount;
import com.bolt.consumersdk.domain.response.CCConsumerApiBridgeDeleteAccountResponse;
import com.bolt.consumersdk.domain.response.CCConsumerApiBridgeGetAccountsResponse;
import com.bolt.consumersdk.domain.response.CCConsumerApiBridgeSaveAccountResponse;
import com.bolt.consumersdk.domain.response.CCConsumerApiBridgeUpdateAccountResponse;
import com.bolt.consumersdk.domain.CCConsumerError;
import com.ccconsumersdk.utils.GsonUtils;

import java.util.ArrayList;

/**
 * Provides an example of {@link CCConsumerApiBridge} implementation
 */
public class ApiBridgeImpl implements CCConsumerApiBridge, Parcelable {
    public static final Creator<ApiBridgeImpl> CREATOR = new Creator<ApiBridgeImpl>() {
        @Override
        public ApiBridgeImpl createFromParcel(Parcel in) {
            return new ApiBridgeImpl(in);
        }

        @Override
        public ApiBridgeImpl[] newArray(int size) {
            return new ApiBridgeImpl[size];
        }
    };
    /**
     * Testing profile Id created by consumer application when adding the first account.
     * In order to be able to fetch/edit/remove account related with one specific profile consumer implementer
     * should provide a profile id. First profile id created will be fetched from {@link CCConsumerAccount} on
     * {@link #saveAccountToCustomer(CCConsumerAccount, CCConsumerApiBridgeCallbacks)}
     */
    private final String PROFILE = "13795514603290869582";

    public ApiBridgeImpl() {
        setupApiConfiguration();
    }

    protected ApiBridgeImpl(Parcel in) {
        // unused
    }

    @Override
    public void getAccounts(@NonNull final CCConsumerApiBridgeCallbacks apiBridgeCallbacks) {
        // TODO: Implement getAccounts from Third party server here, this is just an example implementation
        // TODO: provide result through apiBridgeCallbacks object
        final CCConsumerApiBridgeGetAccountsResponse response = new CCConsumerApiBridgeGetAccountsResponse();
        CardConnect.getInstance().getRestApi().getProfile(PROFILE, null, new RestApiDelegate() {
            @Override
            public void onApiResponse(CardConnectObject cardConnectObject) {
                ArrayList<CCConsumerAccount> accountsResult = new ArrayList<>();

                if (cardConnectObject instanceof ProfilesResponse) {
                    ProfilesResponse profilesResponse = (ProfilesResponse)cardConnectObject;
                    for (ProfileGetResponse profileResponse : profilesResponse.getProfilesResponses()) {
                        if (!ResponseStatus.RESPONSE_STATUS_DECLINED.equals(profileResponse.getResponseStatus())) {
                            CCConsumerAccount account = GsonUtils.getInstance().fromJson(GsonUtils.getInstance()
                                    .toJson(profileResponse), CCConsumerAccount.class);
                            accountsResult.add(account);
                        } else {
                            break;
                        }
                    }
                }
                response.setCCConsumerAccounts(accountsResult);
                apiBridgeCallbacks.onApiResponse(response);
            }

            @Override
            public void onProgressUpdate(Integer integer) {
                // Unused
            }

            @Override
            public void onException(CardConnectError cardConnectError) {
                CCConsumerError error = new CCConsumerError();
                error.setResponseMessage(cardConnectError.getErrorMessage());
                response.setCCConsumerError(error);
                apiBridgeCallbacks.onApiResponse(response);
            }
        });
    }

    @Override
    public void saveAccountToCustomer(@NonNull final CCConsumerAccount account,
            @NonNull final CCConsumerApiBridgeCallbacks apiBridgeCallbacks) {
        // TODO: Implement addAccount to Profile from Third party server here, this is just an example implementation
        // TODO: provide result through apiBridgeCallbacks object
        final CCConsumerApiBridgeSaveAccountResponse response = new CCConsumerApiBridgeSaveAccountResponse();

        ProfileCreateUpdateRequest request = new ProfileCreateUpdateRequest();
        request.setExpiryDate(account.getExpirationDate());
        request.setName(account.getName());
        request.setEmail(account.getEmail());
        request.setPhone(account.getPhone());
        request.setAddress(account.getAddress());
        request.setCity(account.getCity());
        request.setRegion(account.getRegion());
        request.setPostalCode(account.getPostalCode());
        request.setAccountNumber(account.getToken());
        request.setAccountType(account.getAccountType().toString());
        request.setMerchantId(CCConfiguration.getConfigurationMID());
        request.setProfile(PROFILE);

        CardConnect.getInstance().getRestApi().profileCreateUpdate(request, new RestApiDelegate() {
            @Override
            public void onApiResponse(CardConnectObject cardConnectObject) {
                CCConsumerAccount accountResult = new CCConsumerAccount();
                if (cardConnectObject instanceof ProfileCreateUpdateResponse) {
                    ProfileCreateUpdateResponse profileResponse = (ProfileCreateUpdateResponse)cardConnectObject;
                    accountResult = GsonUtils.getInstance().fromJson(GsonUtils.getInstance().toJson(profileResponse),
                            CCConsumerAccount.class);
                }

                response.setCCConsumerAccount(accountResult);
                apiBridgeCallbacks.onApiResponse(response);
            }

            @Override
            public void onProgressUpdate(Integer integer) {
                //Unused
            }

            @Override
            public void onException(CardConnectError cardConnectError) {
                CCConsumerError error = new CCConsumerError();
                error.setResponseMessage(cardConnectError.getErrorMessage());
                response.setCCConsumerError(error);
                apiBridgeCallbacks.onApiResponse(response);
            }
        });
    }

    @Override
    public void deleteCustomerAccount(@NonNull CCConsumerAccount accountToDelete,
            @NonNull final CCConsumerApiBridgeCallbacks apiBridgeCallbacks) {

        // TODO: Implement removeAccount to Profile from Third party server here, this is just an example implementation
        // TODO: provide result through apiBridgeCallbacks object
        final CCConsumerApiBridgeDeleteAccountResponse response = new CCConsumerApiBridgeDeleteAccountResponse();

        CardConnect.getInstance().getRestApi().deleteProfile(PROFILE, accountToDelete.getAccountId(),
                new RestApiDelegate() {
                    @Override
                    public void onApiResponse(CardConnectObject cardConnectObject) {
                        if (cardConnectObject instanceof ProfileDeleteResponse) {
                            apiBridgeCallbacks.onApiResponse(response);
                        }
                    }

                    @Override
                    public void onProgressUpdate(Integer integer) {
                        // Unused
                    }

                    @Override
                    public void onException(CardConnectError cardConnectError) {
                        CCConsumerError error = new CCConsumerError();
                        error.setResponseMessage(cardConnectError.getErrorMessage());
                        response.setCCConsumerError(error);
                        apiBridgeCallbacks.onApiResponse(response);
                    }
                });
    }

    @Override
    public void updateAccount(@NonNull CCConsumerAccount account,
            @NonNull final CCConsumerApiBridgeCallbacks apiBridgeCallbacks) {
        // TODO: Implement updateAccount to Profile from Third party server here, this is just an example implementation
        // TODO: provide result through apiBridgeCallbacks object
        final CCConsumerApiBridgeUpdateAccountResponse response = new CCConsumerApiBridgeUpdateAccountResponse();

        ProfileCreateUpdateRequest request = new ProfileCreateUpdateRequest();
        request.setDefaultAccount(account.isDefaultAccount() ? "Y" : "N");
        request.setAccountNumber(account.getToken());
        request.setExpiryDate(account.getExpirationDate());
        request.setAccountType(account.getAccountType().toString());
        request.setMerchantId(CCConfiguration.getConfigurationMID());
        request.setProfile(PROFILE + "/" + account.getAccountId());
        request.setProfileUpdate("Y");

        CardConnect.getInstance().getRestApi().profileCreateUpdate(request, new RestApiDelegate() {
            @Override
            public void onApiResponse(CardConnectObject cardConnectObject) {
                CCConsumerAccount accountResult = new CCConsumerAccount();
                if (cardConnectObject instanceof ProfileCreateUpdateResponse) {
                    ProfileCreateUpdateResponse profileResponse = (ProfileCreateUpdateResponse)cardConnectObject;
                    accountResult = GsonUtils.getInstance().fromJson(GsonUtils.getInstance().toJson(profileResponse),
                            CCConsumerAccount.class);
                }

                response.setCCConsumerAccount(accountResult);
                apiBridgeCallbacks.onApiResponse(response);
            }

            @Override
            public void onProgressUpdate(Integer integer) {
                //Unused
            }

            @Override
            public void onException(CardConnectError cardConnectError) {
                CCConsumerError error = new CCConsumerError();
                error.setResponseMessage(cardConnectError.getErrorMessage());
                response.setCCConsumerError(error);
                apiBridgeCallbacks.onApiResponse(response);
            }
        });
    }

    private void setupApiConfiguration() {
        CCConfiguration.setConfigurationMID("496160873888");
        CCConfiguration.setConfigurationURL("https://fts.cardconnect.com:6443/cardconnect/rest");
        CCConfiguration.setConfigurationUserName("testing");
        CCConfiguration.setConfigurationPassword("testing123");
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        // Unused
    }
}

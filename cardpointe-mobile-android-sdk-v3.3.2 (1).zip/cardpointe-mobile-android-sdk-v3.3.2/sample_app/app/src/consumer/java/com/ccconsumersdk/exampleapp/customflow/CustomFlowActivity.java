package com.ccconsumersdk.exampleapp.customflow;

import android.os.Bundle;
import androidx.annotation.NonNull;

import com.google.android.material.tabs.TabLayout;
import androidx.appcompat.app.AlertDialog;
import android.view.View;

import com.bolt.consumersdk.CCConsumerTokenCallback;
import com.bolt.consumersdk.domain.CCConsumerAccount;
import com.bolt.consumersdk.domain.CCConsumerCardInfo;
import com.bolt.consumersdk.domain.CCConsumerError;
import com.bolt.consumersdk.enums.CCConsumerMaskFormat;
import com.bolt.consumersdk.views.CCConsumerCreditCardNumberEditText;
import com.bolt.consumersdk.views.CCConsumerCvvEditText;
import com.bolt.consumersdk.views.CCConsumerExpirationDateEditText;
import com.bolt.consumersdk.views.CCConsumerUiTextChangeListener;
import com.ccconsumersdk.apicommunication.ApiBridgeImpl;
import com.ccconsumersdk.exampleapp.BaseActivity;
import com.ccconsumersdk.exampleapp.MainApp;
import com.ccconsumersdk.exampleapp.R;

public class CustomFlowActivity extends BaseActivity {
    private CCConsumerCreditCardNumberEditText mCardNumberEditText;
    private CCConsumerExpirationDateEditText mExpirationDateEditText;
    private CCConsumerCvvEditText mCvvEditText;
    private CCConsumerCardInfo mCCConsumerCardInfo;
    private ApiBridgeImpl mApiBridge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_flow);
        setupToolBar();
        mApiBridge = new ApiBridgeImpl();
        mCardNumberEditText = (CCConsumerCreditCardNumberEditText)findViewById(R.id.text_edit_credit_card_number);
        mExpirationDateEditText =
                (CCConsumerExpirationDateEditText)findViewById(R.id.text_edit_credit_card_expiration_date);
        mCvvEditText = (CCConsumerCvvEditText)findViewById(R.id.text_edit_credit_card_cvv);
        mCCConsumerCardInfo = new CCConsumerCardInfo();

        mCardNumberEditText.setCreditCardTextChangeListener(
                new CCConsumerUiTextChangeListener() {
                    @Override
                    public void onTextChanged() {
                        //This callback will be used for displaying custom UI showing validation completion
                        if (!mCardNumberEditText.isCardNumberValid() && mCardNumberEditText.getText().length() != 0) {
                            mCardNumberEditText.setError(getString(R.string.card_not_valid));
                        } else {
                            mCardNumberEditText.setError(null);
                        }
                    }
                });

        mExpirationDateEditText.setExpirationDateTextChangeListener(new CCConsumerUiTextChangeListener() {
            @Override
            public void onTextChanged() {
                //This callback will be used for displaying custom UI showing validation completion
                if (!mExpirationDateEditText.isExpirationDateValid() &&
                        mExpirationDateEditText.getText().length() != 0) {
                    mExpirationDateEditText.setError(getString(R.string.date_not_valid));
                } else {
                    mExpirationDateEditText.setError(null);
                }
            }
        });

        mCvvEditText.setCvvTextChangeListener(new CCConsumerUiTextChangeListener() {
            @Override
            public void onTextChanged() {
                //This callback will be used for displaying custom UI showing validation completion
                if (!mCvvEditText.isCvvCodeValid() && mCvvEditText.getText().length() != 0) {
                    mCvvEditText.setError(getString(R.string.cvv_not_valid));
                } else {
                    mCvvEditText.setError(null);
                }
            }
        });

        setupTabMaskOptions();
    }

    private void setupTabMaskOptions() {
        TabLayout maskOptionsTabLayout = (TabLayout)findViewById(R.id.tab_layout_mask_options);
        maskOptionsTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        mCardNumberEditText.setCCConsumerMaskFormat(CCConsumerMaskFormat.LAST_FOUR);
                        break;
                    case 1:
                        mCardNumberEditText.setCCConsumerMaskFormat(CCConsumerMaskFormat.FIRST_LAST_FOUR);
                        break;
                    case 2:
                        mCardNumberEditText.setCCConsumerMaskFormat(CCConsumerMaskFormat.CARD_MASK_LAST_FOUR);
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                //Unused
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                //Update default preselection
                if (tab.getPosition() == 0) {
                    mCardNumberEditText.setCCConsumerMaskFormat(CCConsumerMaskFormat.LAST_FOUR);
                }
            }
        });
        TabLayout.Tab selectedTab = maskOptionsTabLayout.getTabAt(0);
        if (selectedTab != null) {
            selectedTab.select();
        }
    }

    public void generateToken(View view) {
        //If using Custom UI Card object needs to be populated from within the component.
        mCardNumberEditText.setCardNumberOnCardInfo(mCCConsumerCardInfo);
        mExpirationDateEditText.setExpirationDateOnCardInfo(mCCConsumerCardInfo);
        mCvvEditText.setCvvCodeOnCardInfo(mCCConsumerCardInfo);

        if (!mCCConsumerCardInfo.isCardValid()) {
            showErrorDialog(getString(R.string.card_invalid));
            return;
        }

        showProgressDialog();
        MainApp.getConsumerApi().generateAccountForCard(mCCConsumerCardInfo, new CCConsumerTokenCallback() {
            @Override
            public void onCCConsumerTokenResponseError(@NonNull CCConsumerError error) {
                dismissProgressDialog();
                showErrorDialog(error.getResponseMessage());
            }

            @Override
            public void onCCConsumerTokenResponse(@NonNull CCConsumerAccount consumerAccount) {
                dismissProgressDialog();
                saveConsumerAccount(consumerAccount);
            }
        });
    }

    private void saveConsumerAccount(@NonNull CCConsumerAccount consumerAccount) {
        mApiBridge.saveAccountToCustomer(consumerAccount, response -> {
            if (response.getCCConsumerError() != null) {
                showErrorDialog(response.getCCConsumerError().getResponseMessage());
            } else {
                promptSuccessfulAccountSave(consumerAccount);
            }
        });
    }

    private void promptSuccessfulAccountSave(@NonNull CCConsumerAccount consumerAccount) {
        String message = getString(R.string.token_generated, consumerAccount.getToken());
        new AlertDialog.Builder(CustomFlowActivity.this).setMessage(message)
                .setNeutralButton(android.R.string.ok, null)
                .show();
    }
}

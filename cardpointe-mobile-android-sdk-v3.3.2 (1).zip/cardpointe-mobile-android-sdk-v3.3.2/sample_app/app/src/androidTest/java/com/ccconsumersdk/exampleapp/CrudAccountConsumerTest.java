package com.ccconsumersdk.exampleapp;

import androidx.test.espresso.ViewInteraction;
import androidx.test.rule.ActivityTestRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.longClick;
import static androidx.test.espresso.action.ViewActions.pressImeActionButton;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.contrib.RecyclerViewActions.actionOnItemAtPosition;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

/**
 * Simple CRUD automated test for implementer interaction with Consumer Integrated UI.
 * <br>
 * <br>
 * When run Profile selected must have at least one account associated with it(Default Account).
 */
@androidx.test.filters.LargeTest
@RunWith(AndroidJUnit4.class)
public class CrudAccountConsumerTest {

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void crudAccountConsumerTest() {
        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.button_integrated_flow), withText("Integrated Flow"), isDisplayed()));
        appCompatButton.perform(click());

        //Adds a new account to the specific Hard Coded profile in the example application
        ViewInteraction consumerButton = onView(
                allOf(withId(R.id.button_add_new_card), withText("Add New Account"), isDisplayed()));
        consumerButton.perform(click());

        ViewInteraction cCConsumerCreditCardNumberEditText = onView(
                allOf(withId(R.id.edit_text_card_number), isDisplayed()));
        cCConsumerCreditCardNumberEditText.perform(typeText("4"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"));
        cCConsumerCreditCardNumberEditText.perform(typeText("1"), closeSoftKeyboard());
        cCConsumerCreditCardNumberEditText.perform(pressImeActionButton());

        ViewInteraction cCConsumerExpirationDateEditText = onView(
                allOf(withId(R.id.edit_text_expiration_date), isDisplayed()));
        cCConsumerExpirationDateEditText.perform(typeText("1"));
        cCConsumerExpirationDateEditText.perform(typeText("2"));
        cCConsumerExpirationDateEditText.perform(typeText("2"));
        cCConsumerExpirationDateEditText.perform(typeText("2"), closeSoftKeyboard());

        ViewInteraction consumerEditText = onView(
                allOf(withId(R.id.edit_text_zip), isDisplayed()));
        consumerEditText.perform(typeText("3"));
        consumerEditText.perform(typeText("3"));
        consumerEditText.perform(typeText("3"), closeSoftKeyboard());

        ViewInteraction consumerButton2 = onView(
                allOf(withId(R.id.button_create_account), withText("Create Account")));
        consumerButton2.perform(scrollTo(), click());

        //Enters to edit mode to be able to edit an specific account
        ViewInteraction consumerButton3 = onView(
                allOf(withId(R.id.button_edit), withText("Edit"), isDisplayed()));
        consumerButton3.perform(click());

        //Opens edit activity to proceed and modify specific values
        //Not require to be the same account previously added
        ViewInteraction recyclerView = onView(allOf(withId(R.id.recycler_view_accounts), isDisplayed()));
        recyclerView.perform(actionOnItemAtPosition(1, click()));

        ViewInteraction cCConsumerExpirationDateEditText1 =
                onView(allOf(withId(R.id.edit_text_expiration_date), isDisplayed()));
        cCConsumerExpirationDateEditText1.perform(clearText());
        cCConsumerExpirationDateEditText1.perform(typeText("1"));
        cCConsumerExpirationDateEditText1.perform(typeText("2"));
        cCConsumerExpirationDateEditText1.perform(typeText("2"));
        cCConsumerExpirationDateEditText1.perform(typeText("2"), closeSoftKeyboard());

        ViewInteraction consumerButton4 = onView(
                allOf(withId(R.id.button_save_account), withText("Save")));
        consumerButton4.perform(scrollTo(), click());

        //Enters to edit mode to be able to delete an specific account
        ViewInteraction consumerButton5 = onView(allOf(withId(R.id.button_edit), withText("Edit"), isDisplayed()));
        consumerButton5.perform(click());

        onView(withId(R.id.recycler_view_accounts)).perform(actionOnItemAtPosition(1, longClick()));

        //Proceed and delete account.
        ViewInteraction appCompatButton2 = onView(allOf(withId(android.R.id.button1), withText("OK")));
        appCompatButton2.perform(scrollTo(), click());

        ViewInteraction consumerButton6 = onView(
                allOf(withId(R.id.button_edit), withText("Cancel"), isDisplayed()));
        consumerButton6.perform(click());

        //Finish Activity
        ViewInteraction consumerButton7 = onView(allOf(withId(R.id.button_back), withText("Back"), isDisplayed()));
        consumerButton7.perform(click());
    }
}

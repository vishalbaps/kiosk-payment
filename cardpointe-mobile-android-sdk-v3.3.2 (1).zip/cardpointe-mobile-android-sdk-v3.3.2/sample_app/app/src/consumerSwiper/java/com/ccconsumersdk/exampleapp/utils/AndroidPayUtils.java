package com.ccconsumersdk.exampleapp.utils;

import com.bolt.consumersdk.androidpay.CCConsumerAndroidPayConfiguration;
import com.google.android.gms.wallet.Cart;
import com.google.android.gms.wallet.LineItem;

import java.util.ArrayList;
import java.util.UUID;

public final class AndroidPayUtils {
    private AndroidPayUtils() {
    }

    public static Cart createExampleCart() {

        //TODO Define what values we are gonna be passed in for payment information for Android Pay.
        CCConsumerAndroidPayConfiguration.getInstance().setMerchantName("Merchant Test Name");
        CCConsumerAndroidPayConfiguration.getInstance().setMerchantTransactionId(UUID.randomUUID().toString());

        LineItem lineItemRegular = LineItem.newBuilder()
                .setCurrencyCode("USD")
                .setDescription("Test Item")
                .setQuantity("1")
                .setUnitPrice("4.00")
                .setTotalPrice("4.00")
                .build();

        LineItem lineItemShipping = LineItem.newBuilder()
                .setCurrencyCode("USD")
                .setDescription("Chipping")
                .setTotalPrice("0.00")
                .setRole(LineItem.Role.SHIPPING)
                .build();

        LineItem lineItemTax = LineItem.newBuilder()
                .setCurrencyCode("USD")
                .setDescription("Tax")
                .setRole(LineItem.Role.TAX)
                .setTotalPrice("0.00")
                .build();

        ArrayList<LineItem> lineItems = new ArrayList<>();
        lineItems.add(lineItemRegular);
        lineItems.add(lineItemShipping);
        lineItems.add(lineItemTax);

        return Cart.newBuilder()
                .setCurrencyCode("USD")
                .setLineItems(lineItems)
                .setTotalPrice("4.00").build();
    }
}

package com.ccconsumersdk.exampleapp.customflow;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.bolt.consumersdk.CCConsumerApiBridgeCallbacks;
import com.bolt.consumersdk.CCConsumerTokenCallback;
import com.bolt.consumersdk.domain.CCConsumerAccount;
import com.bolt.consumersdk.domain.CCConsumerCardInfo;
import com.bolt.consumersdk.domain.CCConsumerError;
import com.bolt.consumersdk.domain.response.CCConsumerApiBridgeResponse;
import com.bolt.consumersdk.enums.CCConsumerMaskFormat;
import com.bolt.consumersdk.swiper.CCSwiperControllerFactory;
import com.bolt.consumersdk.swiper.SwiperController;
import com.bolt.consumersdk.swiper.SwiperControllerListener;
import com.bolt.consumersdk.swiper.enums.BatteryState;
import com.bolt.consumersdk.swiper.enums.SwiperError;
import com.bolt.consumersdk.swiper.enums.SwiperType;
import com.bolt.consumersdk.views.CCConsumerCreditCardNumberEditText;
import com.bolt.consumersdk.views.CCConsumerCvvEditText;
import com.bolt.consumersdk.views.CCConsumerExpirationDateEditText;
import com.bolt.consumersdk.views.CCConsumerUiTextChangeListener;
import com.ccconsumersdk.apicommunication.ApiBridgeImpl;
import com.ccconsumersdk.exampleapp.BaseActivity;
import com.ccconsumersdk.exampleapp.MainApp;
import com.ccconsumersdk.exampleapp.R;

public class CustomFlowActivity extends BaseActivity {
    private static final String TAG = CustomFlowActivity.class.getName();
    private static final int PERMISSIONS_REQUEST_RECORD_AUDIO = 1;
    private SwiperController mSwiperController;
    private CCConsumerCreditCardNumberEditText mCardNumberEditText;
    private CCConsumerExpirationDateEditText mExpirationDateEditText;
    private CCConsumerCvvEditText mCvvEditText;
    private EditText mPostalCodeEditText;
    private CCConsumerCardInfo mCCConsumerCardInfo;

    private ApiBridgeImpl mApiBridge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_flow);
        setupToolBar();
        mApiBridge = new ApiBridgeImpl();
        mCardNumberEditText = (CCConsumerCreditCardNumberEditText)findViewById(R.id.text_edit_credit_card_number);
        mPostalCodeEditText = (EditText)findViewById(R.id.text_edit_credit_card_postal_code);
        mExpirationDateEditText =
                (CCConsumerExpirationDateEditText)findViewById(R.id.text_edit_credit_card_expiration_date);
        mCvvEditText = (CCConsumerCvvEditText)findViewById(R.id.text_edit_credit_card_cvv);
        mCCConsumerCardInfo = new CCConsumerCardInfo();
        mCardNumberEditText.setCreditCardTextChangeListener(
                new CCConsumerUiTextChangeListener() {
                    @Override
                    public void onTextChanged() {
                        // This callback will be used for displaying custom UI showing validation completion
                        if (!mCardNumberEditText.isCardNumberValid() && mCardNumberEditText.getText().length() != 0) {
                            mCardNumberEditText.setError(getString(R.string.card_not_valid));
                        } else {
                            mCardNumberEditText.setError(null);
                        }
                    }
                });

        mExpirationDateEditText.setExpirationDateTextChangeListener(new CCConsumerUiTextChangeListener() {
            @Override
            public void onTextChanged() {
                // This callback will be used for displaying custom UI showing validation completion
                if (!mExpirationDateEditText.isExpirationDateValid() &&
                        mExpirationDateEditText.getText().length() != 0) {
                    mExpirationDateEditText.setError(getString(R.string.date_not_valid));
                } else {
                    mExpirationDateEditText.setError(null);
                }
            }
        });

        mCvvEditText.setCvvTextChangeListener(new CCConsumerUiTextChangeListener() {
            @Override
            public void onTextChanged() {
                // This callback will be used for displaying custom UI showing validation completion
                if (!mCvvEditText.isCvvCodeValid() && mCvvEditText.getText().length() != 0) {
                    mCvvEditText.setError(getString(R.string.cvv_not_valid));
                } else {
                    mCvvEditText.setError(null);
                }
            }
        });
        setupTabMaskOptions();
        // Request android permissions for Swiper
        requestRecordAudioPermission();
    }

    private void setupTabMaskOptions() {
        TabLayout maskOptionsTabLayout = (TabLayout)findViewById(R.id.tab_layout_mask_options);
        maskOptionsTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        mCardNumberEditText.setCCConsumerMaskFormat(CCConsumerMaskFormat.LAST_FOUR);
                        break;
                    case 1:
                        mCardNumberEditText.setCCConsumerMaskFormat(CCConsumerMaskFormat.FIRST_LAST_FOUR);
                        break;
                    case 2:
                        mCardNumberEditText.setCCConsumerMaskFormat(CCConsumerMaskFormat.CARD_MASK_LAST_FOUR);
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Unused
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Update default preselection
                if (tab.getPosition() == 0) {
                    mCardNumberEditText.setCCConsumerMaskFormat(CCConsumerMaskFormat.LAST_FOUR);
                }
            }
        });
        TabLayout.Tab selectedTab = maskOptionsTabLayout.getTabAt(0);
        if (selectedTab != null) {
            selectedTab.select();
        }
    }

    public void generateToken(View view) {

        // If using Custom UI Card object needs to be populated from within the component.
        mCardNumberEditText.setCardNumberOnCardInfo(mCCConsumerCardInfo);
        mExpirationDateEditText.setExpirationDateOnCardInfo(mCCConsumerCardInfo);
        mCvvEditText.setCvvCodeOnCardInfo(mCCConsumerCardInfo);
        mCCConsumerCardInfo.setPostalCode(mPostalCodeEditText.getText().toString());

        if (!mCCConsumerCardInfo.isCardValid()) {
            showErrorDialog(getString(R.string.card_invalid));
            return;
        }

        showProgressDialog();

        MainApp.getConsumerApi().generateAccountForCard(mCCConsumerCardInfo, new CCConsumerTokenCallback() {
            @Override
            public void onCCConsumerTokenResponseError(@NonNull CCConsumerError error) {
                dismissProgressDialog();
                showErrorDialog(error.getResponseMessage());
            }

            @Override
            public void onCCConsumerTokenResponse(@NonNull CCConsumerAccount consumerAccount) {
                dismissProgressDialog();
                Snackbar.make(findViewById(android.R.id.content), getString(R.string.token_generated,
                        consumerAccount.getToken()),
                        Snackbar.LENGTH_SHORT).show();
                mCardNumberEditText.getText().clear();
                mCvvEditText.getText().clear();
                mExpirationDateEditText.getText().clear();
                mApiBridge.saveAccountToCustomer(consumerAccount, new CCConsumerApiBridgeCallbacks() {
                    @Override
                    public void onApiResponse(@NonNull CCConsumerApiBridgeResponse response) {
                        if (response.getCCConsumerError() != null) {
                            showErrorDialog(response.getCCConsumerError().getResponseMessage());
                        } else {
                            finish();
                        }
                    }
                });
            }
        });
    }

    private void initSwiperForTokenGeneration() {
        mSwiperController = new CCSwiperControllerFactory().create(this, SwiperType.BBPosDevice,
                new SwiperControllerListener() {
                    @Override
                    public void onTokenGenerated(CCConsumerAccount account, CCConsumerError error) {
                        dismissProgressDialog();
                        if (error != null) {
                            showErrorDialog(error.getResponseMessage());
                        } else {
                            showSnackBarMessage(account.getToken());
                        }
                    }

                    @Override
                    public void onError(SwiperError swipeError) {
                        Log.d(TAG, swipeError.toString());
                    }

                    @Override
                    public void onSwiperReadyForCard() {
                        Log.d(TAG, "Swiper ready for card");
                        showSnackBarMessage("Swiper ready for card");
                    }

                    @Override
                    public void onSwiperConnected() {
                        Log.d(TAG, "Swiper connected");
                    }

                    @Override
                    public void onSwiperDisconnected() {
                        Log.d(TAG, "Swiper disconnected");
                    }

                    @Override
                    public void onBatteryState(BatteryState batteryState) {
                        Log.d(TAG, batteryState.toString());
                    }

                    @Override
                    public void onStartTokenGeneration() {
                        Log.d(TAG, "Token Generation started.");
                        showProgressDialog();
                    }

                    @Override
                    public void onLogUpdate(String strLogUpdate) {

                    }

                    @Override
                    public void onDeviceConfigurationUpdate(String strUpdate) {

                    }

                    @Override
                    public void onConfigurationProgressUpdate(double dProgress) {

                    }

                    @Override
                    public void onConfigurationComplete(boolean isUpdated) {

                    }

                    @Override
                    public void onTimeout() {

                    }
                },"");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mSwiperController != null) {
            mSwiperController.release();
        }
    }

    private void requestRecordAudioPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.RECORD_AUDIO},
                    PERMISSIONS_REQUEST_RECORD_AUDIO);
        } else {
            initSwiperForTokenGeneration();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        if (requestCode == PERMISSIONS_REQUEST_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initSwiperForTokenGeneration();
            }
        }
    }
}

#import "RootViewController.h"

#import "AppDelegate.h"
#import "APIBridge.h"
#import "ThemingTableViewController.h"

#import <PassKit/PassKit.h>

@interface RootViewController () <UITextFieldDelegate, BMSPaymentControllerDelegate, PKPaymentAuthorizationViewControllerDelegate>

@property (nonatomic, strong) APIBridge *apiBridge;
@property (nonatomic, strong) BMSPaymentController *paymentController;
@property (nonatomic, strong) BMSTheme *theme;

@property (weak, nonatomic) IBOutlet UITextField *endpointTextField;
@property (weak, nonatomic) IBOutlet UIButton *customApplePayButton;
@property (nonatomic, strong) PKPaymentAuthorizationViewController *applePayViewController;
@property (nonatomic) NSString *applePayToken;

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.apiBridge = [APIBridge new];
    self.theme = [BMSTheme new];
    self.theme.disclaimerText = @"Put some explanatory text here. Tell the user about whatever legal stuff you need to.";
    self.paymentController = [[BMSPaymentController alloc] initWithRootView:self apiBridge:self.apiBridge delegate:self theme:self.theme];

    AppDelegate *delegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    if (!(delegate.merchantID.length > 0 &&
        [PKPaymentAuthorizationViewController canMakePayments]))
    {
        self.customApplePayButton.hidden = YES;
    }
    else
    {
        BMSPaymentRequest *request = [BMSPaymentRequest new];
        request.applePayMerchantID = delegate.merchantID;
        request.total = [NSDecimalNumber decimalNumberWithString:@"1.00"];
        request.companyName = @"CardConnect";
        request.additionalData = [@"1234" dataUsingEncoding:NSUTF8StringEncoding];
        
//         Optional: You can provide your own summary items for the payment request
//        PKPaymentSummaryItem *subtotal = [PKPaymentSummaryItem summaryItemWithLabel:@"Subtotal"
//                                                                             amount:[NSDecimalNumber decimalNumberWithString:@"1.00"]];
//        PKPaymentSummaryItem *tax = [PKPaymentSummaryItem summaryItemWithLabel:@"Tax"
//                                                                        amount:[NSDecimalNumber decimalNumberWithString:@"1.00"]];
//        PKPaymentSummaryItem *total = [PKPaymentSummaryItem summaryItemWithLabel:@"CardConnect"
//                                                                          amount:[NSDecimalNumber decimalNumberWithString:@"2.00"]];
//
//        request.paymentSummaryItems = @[subtotal,tax,total];

        self.paymentController.paymentRequest = request;
    }
}
    
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.endpointTextField.text = [BMSAPI instance].endpoint;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {

    if ([segue.destinationViewController isKindOfClass:[ThemingTableViewController class]])
    {
        ((ThemingTableViewController*)segue.destinationViewController).theme = self.theme;
    }
}

- (IBAction)customApplePayPressed:(id)sender
{
    self.applePayToken = nil;
    
    AppDelegate *delegate = (AppDelegate*)[UIApplication sharedApplication].delegate;

    PKPaymentRequest *request = [PKPaymentRequest new];
    request.currencyCode = @"USD";
    request.countryCode = @"US";
    request.merchantIdentifier = delegate.merchantID;

    NSDecimalNumber *total = [NSDecimalNumber decimalNumberWithString:@"1.00"];
    request.paymentSummaryItems = @[[PKPaymentSummaryItem summaryItemWithLabel:NSLocalizedString(@"Your Company name", @"ApplePay total label")
                                                                        amount:total]];
    request.supportedNetworks = @[PKPaymentNetworkMasterCard, PKPaymentNetworkVisa, PKPaymentNetworkAmex];
    request.merchantCapabilities = PKMerchantCapability3DS;

    self.applePayViewController = [[PKPaymentAuthorizationViewController alloc] initWithPaymentRequest:request];
    self.applePayViewController.delegate = self;
    [self presentViewController:self.applePayViewController animated:YES completion:nil];
}

- (IBAction)integratedFlowPressed:(id)sender
{
    [self.paymentController presentPaymentView];
}

- (IBAction)stackIntegratedFlowPressed:(id)sender
{
    [self.paymentController pushPaymentView];
}
    
#pragma mark - UITextFieldDelegate -

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    [BMSAPI instance].endpoint = newString;
    
    return YES;
}

#pragma mark - BMSPaymentControllerDelegate -

- (void)paymentController:(BMSPaymentController *)controller finishedWithAccount:(BMSAccount *)account
{
    if (account)
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Token Generated" message:account.token preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    }
    else
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error" message:@"An unknown error" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

- (void)paymentController:(BMSPaymentController *)controller finishedApplePayWithResult:(BOOL)result
{
    
}

- (void)didCancelPaymentController:(BMSPaymentController *)controller
{

}

#pragma mark - ApplePay -

- (void)paymentAuthorizationViewController:(PKPaymentAuthorizationViewController *)controller didAuthorizePayment:(PKPayment *)payment completion:(void (^)(PKPaymentAuthorizationStatus))completion
{
    [[BMSAPI instance] generateTokenForApplePay:payment completion:^(NSString * _Nullable token, NSError * _Nullable error) {
        if (token)
        {
            self.applePayToken = token;
            
            // Perform your auth with the token at this point
            [self.apiBridge BMS_authApplePayTransactionWithToken:token completion:^(BOOL result, NSError *error) {

                completion(result?PKPaymentAuthorizationStatusSuccess:PKPaymentAuthorizationStatusFailure);
            }];
        }
        else
        {
            completion(PKPaymentAuthorizationStatusFailure);
        }
    }];
}

- (void)paymentAuthorizationViewControllerDidFinish:(PKPaymentAuthorizationViewController *)controller
{
    [controller dismissViewControllerAnimated:YES completion:nil];
    
    if (self.applePayToken)
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Token Generated" message:self.applePayToken preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

@end

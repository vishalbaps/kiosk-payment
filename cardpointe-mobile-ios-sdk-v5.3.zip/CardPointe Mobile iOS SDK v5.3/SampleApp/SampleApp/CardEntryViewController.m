#import "CardEntryViewController.h"

#import <PassKit/PassKit.h>

#import "AppDelegate.h"

@interface CardEntryViewController () <BMSFormatterDelegateExtension,BMSSwiperControllerDelegate, PKPaymentAuthorizationViewControllerDelegate>

@property (weak, nonatomic) IBOutlet UITextField *cardNumberTextField;
@property (weak, nonatomic) IBOutlet UITextField *expirationDateTextField;
@property (weak, nonatomic) IBOutlet UITextField *CVVTextField;
@property (weak, nonatomic) IBOutlet UITextField *postalCodeTextField;

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UILabel *swiperStatus;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *generateTokenBarButton;

@property (weak, nonatomic) IBOutlet UISegmentedControl *maskFormatSegmentedControl;
@property (weak, nonatomic) IBOutlet UISegmentedControl *maskCharacterSegmentedControl;
@property (weak, nonatomic) IBOutlet UIButton *restartReaderButton;

@property (strong, nonatomic) IBOutlet BMSCardFormatterDelegate *cardFormatterDelegate;
@property (strong, nonatomic) IBOutlet BMSExpirationDateFormatterDelegate *expirationFormatterDelegate;
@property (strong, nonatomic) IBOutlet BMSCVVFormatterDelegate *cvvFormatterDelegate;

@property (weak, nonatomic) IBOutlet UISwitch *swipeOnlySwitch;
@property (weak, nonatomic) IBOutlet UIButton *connectButton;

@property (nonatomic, strong) BMSSwiperController *swiper;
@property (nonatomic, strong) UIAlertController *communicationAlert;

@property (nonatomic, strong) PKPaymentButton *applePayButton;
@property (nonatomic, strong) PKPaymentAuthorizationViewController *applePayViewController;

@property (nonatomic, strong) BMSCardInfo *card;
@property (nonatomic, copy) void(^restartReaderBlock)(void);

@end

@implementation CardEntryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.card = [BMSCardInfo new];

    self.cardNumberTextField.rightViewMode = UITextFieldViewModeAlways;
    self.expirationDateTextField.rightViewMode = UITextFieldViewModeAlways;
    self.CVVTextField.rightViewMode = UITextFieldViewModeAlways;

    if ([PKPaymentAuthorizationViewController canMakePayments] &&
        [PKPaymentAuthorizationViewController canMakePaymentsUsingNetworks:@[PKPaymentNetworkMasterCard, PKPaymentNetworkVisa, PKPaymentNetworkAmex]] &&
        ((AppDelegate*)[UIApplication sharedApplication].delegate).merchantID.length > 0)
    {
        self.applePayButton = [PKPaymentButton buttonWithType:PKPaymentButtonTypePlain style:PKPaymentButtonStyleBlack];
        [self.applePayButton addTarget:self action:@selector(applePayPressed:) forControlEvents:UIControlEventTouchUpInside];
        self.applePayButton.translatesAutoresizingMaskIntoConstraints = NO;
        [self.view addSubview:self.applePayButton];
        [self.view addConstraints:@[[NSLayoutConstraint constraintWithItem:self.applePayButton attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.swiperStatus attribute:NSLayoutAttributeCenterX multiplier:1.0f constant:0],
                                    [NSLayoutConstraint constraintWithItem:self.applePayButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.swiperStatus attribute:NSLayoutAttributeBottom multiplier:1.0f constant:10]]];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated
{
    if (_swiper)
    {
        [_swiper releaseDevice];
        _swiper = nil;
    }

    [super viewWillDisappear:animated];
}

#pragma mark Internal Methods

- (void)i_startActivityIndicator
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.activityIndicator startAnimating];
        [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    });
}

- (void)i_stopActivityIndicator
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.activityIndicator stopAnimating];
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    });
}

- (void)i_updateCreateButton
{
    self.generateTokenBarButton.enabled =   self.cardFormatterDelegate.isValidCard &&
                                            self.expirationFormatterDelegate.isValidExpirationDate &&
                                            self.cvvFormatterDelegate.isValidCVV;
}

- (void)i_showCommunicationAlertWithMessage:(NSString*)message cancelable:(BOOL)canCancel
{
    if (self.communicationAlert == nil)
    {
        self.communicationAlert = [UIAlertController alertControllerWithTitle:@"" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    }
    
    self.communicationAlert.message = message;
    
    if (canCancel &&
        self.communicationAlert.actions.count == 0)
    {
        [self.communicationAlert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            self.communicationAlert = nil;
            [self.swiper cancelFindDevices];
        }]];
    }
    else if (!canCancel &&
             self.communicationAlert.actions.count > 0)
    {
        for (UIAlertAction *action in self.communicationAlert.actions)
        {
            action.enabled = NO;
        }
    }
    
    if (!self.presentedViewController)
    {
        [self presentViewController:self.communicationAlert animated:YES completion:nil];
    }
}

#pragma mark Action Methods

- (IBAction)createPressed:(id)sender
{
    [self.view endEditing:YES];

    [self i_startActivityIndicator];

    [[BMSAPI instance] generateAccountForCard:self.card completion:^(BMSAccount * _Nullable account, NSError * _Nullable error) {
        [self i_stopActivityIndicator];

        [self.cardFormatterDelegate clearTextField];
        [self.expirationFormatterDelegate clearTextField];
        [self.cvvFormatterDelegate clearTextField];
        self.postalCodeTextField.text = @"";
        self.card = [BMSCardInfo new];
        [self i_updateCreateButton];

        if (account)
        {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Token Generated" message:account.token preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
        }
        else
        {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error" message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }];
}

- (IBAction)segmentedControlValueChanged:(UISegmentedControl*)sender
{
    if (sender == self.maskFormatSegmentedControl)
    {
        switch (sender.selectedSegmentIndex) {
            case 0:
                self.cardFormatterDelegate.maskFormat = BMSCardMaskFormatMaskWithLastFour;
                break;
            case 1:
                self.cardFormatterDelegate.maskFormat = BMSCardMaskFormatLastFour;
                break;
            case 2:
                self.cardFormatterDelegate.maskFormat = BMSCardMaskFormatFirstAndLastFour;
                break;
            default:
                break;
        }
    }
    else
    {
        switch (sender.selectedSegmentIndex) {
            case 0:
                self.cardFormatterDelegate.maskCharacter = '*';
                self.cvvFormatterDelegate.maskCharacter = '*';
                break;
            case 1:
                self.cardFormatterDelegate.maskCharacter = '&';
                self.cvvFormatterDelegate.maskCharacter = '&';
                break;
            case 2:
                self.cardFormatterDelegate.maskCharacter = '-';
                self.cvvFormatterDelegate.maskCharacter = '-';
                break;
            default:
                break;
        }
    }
}

- (IBAction)restartReaderPressed:(id)sender
{
    self.restartReaderButton.enabled = NO;
    
    if (self.restartReaderBlock &&
        self.swiper.connectionState == BMSSwiperConnectionStateConnected)
    {
        self.restartReaderBlock();
    }
}

- (IBAction)connectPressed:(UIButton*)sender
{
    AppDelegate *appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    
    _swiper = [[BMSSwiperController alloc] initWithDelegate:self swiper:appDelegate.swiperType loggingEnabled:YES];
    
#pragma mark Change this to disable the swiper sounds
//    _swiper.beepSetting = BMSDeviceBeepSettingNone
    
    if (appDelegate.swiperType != BMSSwiperTypeBBPOS &&
        appDelegate.device)
    {
        BMSCardReadMode readMode = appDelegate.swiperType == BMSSwiperTypeVP3300?BMSCardReadModeSwipeDipTap:BMSCardReadModeSwipeDip;
        [_swiper connectToDevice:appDelegate.device.uuid mode:self.swipeOnlySwitch.isOn?BMSCardReadModeSwipe:readMode];
    }
}

- (void)applePayPressed:(PKPaymentButton*)paymentButton
{
    PKPaymentRequest *request = [PKPaymentRequest new];
    request.currencyCode = @"USD";
    request.countryCode = @"US";
    request.merchantIdentifier = ((AppDelegate*)[UIApplication sharedApplication].delegate).merchantID;

    NSDecimalNumber *total = [NSDecimalNumber decimalNumberWithString:@"1.00"];
    request.paymentSummaryItems = @[[PKPaymentSummaryItem summaryItemWithLabel:@"Total" amount:total]];
    request.supportedNetworks = @[PKPaymentNetworkMasterCard, PKPaymentNetworkVisa, PKPaymentNetworkAmex];
    request.merchantCapabilities = PKMerchantCapability3DS;

    self.applePayViewController = [[PKPaymentAuthorizationViewController alloc] initWithPaymentRequest:request];
    self.applePayViewController.delegate = self;
    [self presentViewController:self.applePayViewController animated:YES completion:nil];
}

#pragma mark BMSFormatterDelegateExtension

- (void)didChangeCharactersInRangeForFormatter:(BMSTextFieldDelegateProxy *)formatter
{
    if (formatter == self.cardFormatterDelegate)
    {
        if (self.cardNumberTextField.text.length > 0 &&
            !self.cardFormatterDelegate.isValidCard)
        {
            UILabel *xLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
            xLabel.text = @"X";
            xLabel.textColor = [UIColor redColor];
            xLabel.font = [UIFont boldSystemFontOfSize:20];
            xLabel.textAlignment = NSTextAlignmentCenter;

            self.cardNumberTextField.rightView = xLabel;
        }
        else
        {
            self.cardNumberTextField.rightView = nil;
            [self.cardFormatterDelegate setCardNumberOnCardInfo:self.card];
        }
    }
    else if (formatter == self.expirationFormatterDelegate)
    {
        if (self.expirationDateTextField.text.length > 0 &&
            !self.expirationFormatterDelegate.isValidExpirationDate)
        {
            UILabel *xLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
            xLabel.text = @"X";
            xLabel.textColor = [UIColor redColor];
            xLabel.font = [UIFont boldSystemFontOfSize:20];
            xLabel.textAlignment = NSTextAlignmentCenter;

            self.expirationDateTextField.rightView = xLabel;
        }
        else
        {
            self.expirationDateTextField.rightView = nil;
            [self.expirationFormatterDelegate setExpirationDateOnCardInfo:self.card];
        }
    }
    else if (formatter == self.cvvFormatterDelegate)
    {
        if (self.CVVTextField.text.length > 0 &&
            ![self.cvvFormatterDelegate isValidCVVWithCardFormatter:self.cardFormatterDelegate])
        {
            UILabel *xLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
            xLabel.text = @"X";
            xLabel.textColor = [UIColor redColor];
            xLabel.font = [UIFont boldSystemFontOfSize:20];
            xLabel.textAlignment = NSTextAlignmentCenter;

            self.CVVTextField.rightView = xLabel;
        }
        else
        {
            self.CVVTextField.rightView = nil;
            [self.cvvFormatterDelegate setCVVOnCardInfo:self.card];
        }
    }

    [self i_updateCreateButton];
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    if (textField == self.cardNumberTextField)
    {
        self.card.cardNumber = nil;
    }
    else if (textField == self.expirationDateTextField)
    {
        self.card.expirationDate = nil;
    }
    else if (textField == self.CVVTextField)
    {
        self.card.CVV = nil;
    }

    [self i_updateCreateButton];

    return YES;
}

#pragma mark Swiper Delegate

- (void)swiper:(BMSSwiper *)swiper connectionStateHasChanged:(BMSSwiperConnectionState)state
{
    switch (state) {
        case BMSSwiperConnectionStateConnected:
            NSLog(@"Did Connect Swiper");
            self.swiperStatus.text = @"Connected";
            self.connectButton.enabled = NO;
            [self i_showCommunicationAlertWithMessage:@"Connected" cancelable:NO];
            break;
        case BMSSwiperConnectionStateDisconnected:
            NSLog(@"Did Disconnect Swiper");
            self.swiperStatus.text = @"Disconnected";
            self.connectButton.enabled = YES;
            self.restartReaderButton.enabled = NO;
            if (self.communicationAlert)
            {
                if (self.presentedViewController == self.communicationAlert)
                {
                    [self.communicationAlert dismissViewControllerAnimated:YES completion:^{
                        self.communicationAlert = nil;
                    }];
                }
                else
                {
                    self.communicationAlert = nil;
                }
            }
            break;
        case BMSSwiperConnectionStateConfiguring:
            NSLog(@"Configuring Device");
            self.swiperStatus.text = @"Configuring";
            self.connectButton.enabled = NO;
            [self i_showCommunicationAlertWithMessage:@"Configuring" cancelable:NO];
            break;
        case BMSSwiperConnectionStateConnecting:
            NSLog(@"Will Connect Swiper");
            self.swiperStatus.text = @"Connecting";
            self.connectButton.enabled = NO;
            [self i_showCommunicationAlertWithMessage:@"Connecting" cancelable:NO];
                break;
        case BMSSwiperConnectionStateSearching:
            NSLog(@"Will search for Swiper");
            self.swiperStatus.text = @"Searching";
            self.connectButton.enabled = NO;
            [self i_showCommunicationAlertWithMessage:@"Searching" cancelable:YES];
            break;
        default:
            break;
    }
}

- (void)swiperDidStartCardRead:(BMSSwiper *)swiper
{
    NSLog(@"Card Read Started");
    [self.view endEditing:YES];
    
    [self i_showCommunicationAlertWithMessage:@""
                                   cancelable:YES];
}

- (void)swiper:(BMSSwiper *)swiper didGenerateTokenWithAccount:(BMSAccount *)account completion:(void (^)(void))completion
{
    [self i_stopActivityIndicator];
    
    if (self.communicationAlert)
    {
        [self.communicationAlert dismissViewControllerAnimated:YES completion:^{
            self.communicationAlert = nil;
        }];
    }
    
    if (account)
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Token Generated" message:account.token preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"Retry" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            completion();
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:@"Done" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            self.restartReaderBlock = completion;
            self.restartReaderButton.enabled = YES;
        }]];
        [self presentViewController:alert animated:YES completion:nil];
    }
    else
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error" message:@"An unknown error" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"Retry" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            completion();
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            self.restartReaderBlock = completion;
            self.restartReaderButton.enabled = YES;
        }]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

- (void)swiper:(BMSSwiper *)swiper didFailWithError:(NSError *)error completion:(void (^)(void))completion
{
    [self i_stopActivityIndicator];
    
    if (self.communicationAlert)
    {
         [self.communicationAlert dismissViewControllerAnimated:YES completion:^{
             self.communicationAlert = nil;
         }];
    }

    NSMutableString *errorMessage = [[NSMutableString alloc] initWithFormat:@"An error occured:\n%@",error.localizedDescription];
    
    if ([error.userInfo valueForKey:@"firmwareVersion"])
    {
        [errorMessage appendFormat:@"\n\n%@", [error.userInfo valueForKey:@"firmwareVersion"]];
    }
    
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@""
                                                                        message:errorMessage
                                                                 preferredStyle:UIAlertControllerStyleAlert];
    [controller addAction:[UIAlertAction actionWithTitle:@"Retry" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        completion();
    }]];
    [controller addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        self.restartReaderBlock = completion;
        self.restartReaderButton.enabled = YES;
    }]];
    [self presentViewController:controller animated:YES completion:nil];
}

- (void)swiper:(BMSSwiperController*)swiper foundDevices:(NSArray*)devices
{
    
}

- (void)swiper:(BMSSwiperController*)swiper displayMessage:(NSString*)message canCancel:(BOOL)cancelable
{
    [self i_showCommunicationAlertWithMessage:message
                                   cancelable:cancelable];
}

- (void)swiper:(BMSSwiperController *)swiper configurationProgress:(float)progress
{
    [self i_showCommunicationAlertWithMessage:[NSString stringWithFormat:@"Configuring: %.0f%%",progress*100]
                                   cancelable:NO];
}

#pragma mark PKPaymentAuthorizationViewControllerDelegate

- (void)paymentAuthorizationViewController:(PKPaymentAuthorizationViewController *)controller
                       didAuthorizePayment:(PKPayment *)payment
                                completion:(void (^)(PKPaymentAuthorizationStatus status))completion
{
    [[BMSAPI instance] generateTokenForApplePay:payment completion:^(NSString * _Nullable token, NSError * _Nullable error) {
        if (token) {
            completion(PKPaymentAuthorizationStatusSuccess);
        }
        else
        {
            completion(PKPaymentAuthorizationStatusFailure);
        }
    }];
}

- (void)paymentAuthorizationViewControllerDidFinish:(PKPaymentAuthorizationViewController *)controller
{
    [controller dismissViewControllerAnimated:YES completion:nil];
}

@end

//
//  SwiperConfigurationViewController.m
//  SampleApp
//
//  Created by Nick Rimer on 3/6/19.
//  Copyright © 2019 iMobile3 LLC. All rights reserved.
//

#import "SwiperConfigurationViewController.h"

#import "AppDelegate.h"

@interface SwiperConfigurationViewController () <UITableViewDelegate, UITableViewDataSource, BMSSwiperControllerDelegate>
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControl;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic) BMSSwiperController *swiper;
@property (nonatomic) NSArray<BMSDevice*> *foundDevices;
@property (nonatomic) BMSDevice *tempDevice;

@property (nonatomic) UIAlertController *alert;

@end

@implementation SwiperConfigurationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)viewWillDisappear:(BOOL)animated
{
    AppDelegate *delegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    
    if (self.segmentedControl.selectedSegmentIndex == BMSSwiperTypeBBPOS)
    {
        delegate.swiperType = BMSSwiperTypeBBPOS;
        delegate.device = nil;
    }
    
    [_swiper releaseDevice];
    _swiper = nil;
    
    [super viewWillDisappear:animated];
}

- (IBAction)segmentedControllerValueChanged:(UISegmentedControl*)sender
{
    if (sender.selectedSegmentIndex == 1)
    {
        
        [_swiper releaseDevice];
        _swiper = nil;
        
        _swiper = [[BMSSwiperController alloc] initWithDelegate:self swiper:BMSSwiperTypeVP3300 loggingEnabled:YES];
        [_swiper findDevices];
    }
    else if (sender.selectedSegmentIndex == 2)
    {
        [_swiper releaseDevice];
        _swiper = nil;
        
        _swiper = [[BMSSwiperController alloc] initWithDelegate:self swiper:BMSSwiperTypeVP3600 loggingEnabled:YES];
        [_swiper findDevices];
    }
    else
    {
        [_swiper cancelFindDevices];
        self.foundDevices = nil;
    }
    
    [self.tableView reloadData];
}

#pragma mark TableView Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.segmentedControl.selectedSegmentIndex == 0)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.foundDevices.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = self.foundDevices[indexPath.row].name;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [_swiper cancelFindDevices];
    
    self.tempDevice = self.foundDevices[indexPath.row];
    [_swiper connectToDevice:self.tempDevice.uuid mode:BMSCardReadModeSwipe];
    
    self.alert = [UIAlertController alertControllerWithTitle:@"" message:@"Connecting" preferredStyle:UIAlertControllerStyleAlert];
    
    [self presentViewController:self.alert animated:YES completion:nil];
}

#pragma mark Swiper Delegate

- (void)swiper:(BMSSwiper *)swiper connectionStateHasChanged:(BMSSwiperConnectionState)state
{
    switch (state) {
        case BMSSwiperConnectionStateConnected:
            NSLog(@"Did Connect Swiper");
            break;
        case BMSSwiperConnectionStateDisconnected:
            NSLog(@"Did Disconnect Swiper");
            break;
        case BMSSwiperConnectionStateConnecting:
            NSLog(@"Will Connect Swiper");
            break;
        case BMSSwiperConnectionStateConfiguring:
            NSLog(@"Configuring");
            break;
        case BMSSwiperConnectionStateSearching:
            NSLog(@"Searching");
            break;
        default:
            break;
    }
}

- (void)swiperDidStartCardRead:(BMSSwiper *)swiper
{
    __weak SwiperConfigurationViewController *weakSelf = self;
    // This is required to give the terminal enough time to finish starting before canceling
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [weakSelf.swiper cancelTransaction];
    });
}

- (void)swiper:(BMSSwiper *)swiper didGenerateTokenWithAccount:(BMSAccount *)account completion:(void (^)(void))completion
{
}

- (void)swiper:(BMSSwiper *)swiper didFailWithError:(NSError *)error completion:(void (^)(void))completion
{
    // If we connected to the device, we canceled the transaction and should save the device.
    if ([error.domain isEqualToString:BMSSwiperErrorDomain] &&
        error.code == BMSSwiperErrorCanceledTransaction)
    {
        AppDelegate *delegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
        
        delegate.swiperType = self.segmentedControl.selectedSegmentIndex == 1?BMSSwiperTypeVP3300:BMSSwiperTypeVP3600;
        delegate.device = self.tempDevice;
        
        if (self.alert)
        {
            [self.alert dismissViewControllerAnimated:YES completion:^{
                self.alert = nil;
                [self.navigationController popViewControllerAnimated:YES];
            }];
        }
        else
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
        return;
    }

    NSMutableString *errorMessage = [[NSMutableString alloc] initWithFormat:@"An error occured:\n%@",error.localizedDescription];
    
    if ([error.userInfo valueForKey:@"firmwareVersion"])
    {
        [errorMessage appendFormat:@"\n\n%@", [error.userInfo valueForKey:@"firmwareVersion"]];
    }
    
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@""
                                                                        message:errorMessage
                                                                 preferredStyle:UIAlertControllerStyleAlert];
    [controller addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [controller addAction:[UIAlertAction actionWithTitle:@"RETRY" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        completion();
    }]];
    
    if (self.alert)
    {
        [self.alert dismissViewControllerAnimated:YES completion:^{
            self.alert = nil;
            [self presentViewController:controller animated:YES completion:nil];
        }];
    }
    else
    {
        [self presentViewController:controller animated:YES completion:nil];
    }
}

- (void)swiper:(BMSSwiperController*)swiper foundDevices:(NSArray*)devices
{
    self.foundDevices = devices;
    [self.tableView reloadData];
}

- (void)swiper:(BMSSwiperController*)swiper displayMessage:(NSString*)message canCancel:(BOOL)cancelable
{
}

- (void)swiper:(BMSSwiperController *)swiper configurationProgress:(float)progress
{
    self.alert.message = [NSString stringWithFormat:@"Configuring: %.0f%%",progress*100];
}

@end

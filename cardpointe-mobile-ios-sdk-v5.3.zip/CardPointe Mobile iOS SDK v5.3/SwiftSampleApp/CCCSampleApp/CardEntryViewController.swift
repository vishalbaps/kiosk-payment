/*
 
 Copyright (c) 2017 iMobile3, LLC. All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, is permitted provided that adherence to the following
 conditions is maintained. If you do not agree with these terms,
 please do not use, install, modify or redistribute this software.
 
 1. Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.
 
 THIS SOFTWARE IS PROVIDED BY IMOBILE3, LLC "AS IS" AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 EVENT SHALL IMOBILE3, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
 */

import UIKit
import BoltMobileSDK

class CardEntryViewController: UIViewController, BMSFormatterDelegateExtension, BMSSwiperControllerDelegate {

    @IBOutlet weak var cardNumberTextField: UITextField!
    @IBOutlet weak var expirationDateTextField: UITextField!
    @IBOutlet weak var CVVTextField: UITextField!
    @IBOutlet weak var postalCodeTextField: UITextField!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var swiperStatusLabel: UILabel!
    
    @IBOutlet weak var generateTokenBarButton: UIBarButtonItem!
    
    @IBOutlet weak var maskFormatSegmentedControl: UISegmentedControl!
    @IBOutlet weak var maskCharacterSegmentedControl: UISegmentedControl!
    @IBOutlet weak var restartReaderButton: UIButton!
    
    @IBOutlet weak var cardFormatterDelegate: BMSCardFormatterDelegate!
    @IBOutlet weak var expirationFormatterDelegate: BMSExpirationDateFormatterDelegate!
    @IBOutlet weak var cvvFormatterDelegate: BMSCVVFormatterDelegate!
    
    @IBOutlet weak var swipeOnlySwitch: UISwitch!
    @IBOutlet weak var connectButton: UIButton!
    
    var swiper: BMSSwiperController?
    var alert: UIAlertController?
    var communicationAlert: UIAlertController?
    var card: BMSCardInfo!
    var restartReaderBlock: (()->())? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        card = BMSCardInfo()
        
        cardNumberTextField.rightViewMode = .always
        expirationDateTextField.rightViewMode = .always
        CVVTextField.rightViewMode = .always
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        if swiper != nil {
            swiper!.releaseDevice()
            swiper = nil
        }
    }
    
    // MARK: - Internal Methods -
    
    func i_startActivityIndicator() {
        DispatchQueue.main.async {
            self.activityIndicator.startAnimating()
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
    }
    
    func i_stopActivityIndicator() {
        DispatchQueue.main.async {
            self.activityIndicator.stopAnimating()
            UIApplication.shared.endIgnoringInteractionEvents()
        }
    }
    
    func i_updateCreateButton() {
        self.generateTokenBarButton.isEnabled = self.cardFormatterDelegate.isValidCard &&
                                                self.expirationFormatterDelegate.isValidExpirationDate &&
                                                self.cvvFormatterDelegate.isValidCVV()
    }
    
    func i_showCommunicationAlertWith(message:String, cancelable:Bool) {
        if self.communicationAlert == nil {
            self.communicationAlert = UIAlertController(title: "", message: "", preferredStyle: .alert)
        }
        
        self.communicationAlert?.message = message;
        
        if cancelable && self.communicationAlert?.actions.count == 0 {
            self.communicationAlert?.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (UIAlertAction) in
                self.communicationAlert = nil
                self.swiper?.cancelFindDevices()
            }))
        }
        else if !cancelable && (self.communicationAlert?.actions.count)! > 0 {
            for action in (self.communicationAlert?.actions)!
            {
                action.isEnabled = false;
            }
        }
        
        if self.presentedViewController == nil {
            self.present(self.communicationAlert!, animated: true, completion: nil)
        }
    }
    
    // MARK: - Action Methods -

    @IBAction func generateTokenPressed(_ sender: Any) {
        self.view.endEditing(true)
        
        i_startActivityIndicator()
        
        BMSAPI.instance().generateAccount(forCard: card) { (account: BMSAccount?, error: Error?) in
            self.i_stopActivityIndicator()
            
            self.cardFormatterDelegate.clearTextField()
            self.expirationFormatterDelegate.clearTextField()
            self.cvvFormatterDelegate.clearTextField()
            self.postalCodeTextField.text = ""
            self.card = BMSCardInfo()
            
            self.i_updateCreateButton()
            
            if let account = account {
                let alert = UIAlertController(title: "Token Generated", message: account.token, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            } else if let error = error {
                let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func segmentedControlValueChanged(_ sender: UISegmentedControl) {
        if sender == self.maskFormatSegmentedControl {
            switch sender.selectedSegmentIndex {
            case 0:
                self.cardFormatterDelegate.maskFormat = .maskWithLastFour
                break
            case 1:
                self.cardFormatterDelegate.maskFormat = .lastFour
                break
            case 2:
                self.cardFormatterDelegate.maskFormat = .firstAndLastFour
                break
            default:
                break
            }
        } else {
            switch sender.selectedSegmentIndex {
            case 0:
                let charString = "*"
                
                self.cardFormatterDelegate.maskCharacter = charString.utf16.first!
                self.cvvFormatterDelegate.maskCharacter = charString.utf16.first!
                
                break
            case 1:
                let charString = "&"
                
                self.cardFormatterDelegate.maskCharacter = charString.utf16.first!
                self.cvvFormatterDelegate.maskCharacter = charString.utf16.first!
                break
            case 2:
                let charString = "-"
                
                self.cardFormatterDelegate.maskCharacter = charString.utf16.first!
                self.cvvFormatterDelegate.maskCharacter = charString.utf16.first!
                break
            default:
                break
            }
        }
    }
    
    @IBAction func restartReaderPressed(_ sender: Any) {
        self.restartReaderButton.isEnabled = false
        if self.restartReaderBlock != nil &&
            self.swiper?.connectionState == BMSSwiperConnectionState.connected {
            self.restartReaderBlock!()
        }
    }
    
    @IBAction func connectPressed(_ sender: UIButton) {
        let delegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
        
        swiper = BMSSwiperController(delegate: self, swiper: delegate.swiperType, loggingEnabled: true)
        
        // MARK: Change this to disable the swiper sounds
//        swiper?.beepSetting = BMSDeviceBeepSetting.settingNone
        
        if delegate.swiperType != BMSSwiperType.BBPOS &&
            delegate.device != nil
        {
            let readMode = delegate.swiperType == BMSSwiperType.VP3300 ? BMSCardReadMode.swipeDipTap : BMSCardReadMode.swipeDip
            swiper?.connect(toDevice: delegate.device?.uuid, mode: self.swipeOnlySwitch.isOn ? BMSCardReadMode.swipe:readMode)
        }
    }
    
    // MARK: - BMSFormatterDelegateExtension Methods -
    
    func didChangeCharactersInRange(forFormatter formatter: BMSTextFieldDelegateProxy!) {
        if formatter == self.cardFormatterDelegate {
            if let cardNumberText = self.cardNumberTextField.text,
                (cardNumberText.count > 0 &&
                !self.cardFormatterDelegate.isValidCard) {
                let xLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
                xLabel.text = "X"
                xLabel.textColor = UIColor.red
                xLabel.font = UIFont.boldSystemFont(ofSize: 20)
                xLabel.textAlignment = .center
                
                self.cardNumberTextField.rightView = xLabel
            } else {
                self.cardNumberTextField.rightView = nil
                self.cardFormatterDelegate.setCardNumberOn(card)
            }
        } else if formatter == self.expirationFormatterDelegate {
            if let expirationDateText = self.expirationDateTextField.text,
                (expirationDateText.count > 0 &&
                !self.expirationFormatterDelegate.isValidExpirationDate) {
                let xLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
                xLabel.text = "X"
                xLabel.textColor = UIColor.red
                xLabel.font = UIFont.boldSystemFont(ofSize: 20)
                xLabel.textAlignment = .center
                
                self.expirationDateTextField.rightView = xLabel
            } else {
                self.expirationDateTextField.rightView = nil
                self.expirationFormatterDelegate.setExpirationDateOn(card)
            }
        } else if formatter == self.cvvFormatterDelegate {
            if let cvvText = self.CVVTextField.text,
                (cvvText.count > 0 &&
                !self.cvvFormatterDelegate.isValidCVV()) {
                let xLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
                xLabel.text = "X"
                xLabel.textColor = UIColor.red
                xLabel.font = UIFont.boldSystemFont(ofSize: 20)
                xLabel.textAlignment = .center
                
                self.CVVTextField.rightView = xLabel
            } else {
                self.CVVTextField.rightView = nil
                self.cvvFormatterDelegate.setCVVOn(card)
            }
        }
        
        i_updateCreateButton()
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        if textField == self.cardNumberTextField {
            card.cardNumber = nil
        } else if textField == self.expirationDateTextField {
            card.expirationDate = nil
        } else if textField == self.CVVTextField {
            card.cvv = nil
        }
        
        i_updateCreateButton()
        
        return true
    }
    
    // MARK: - SwiperDelegate Methods -
    
    func swiper(_ swiper: BMSSwiper, connectionStateHasChanged state: BMSSwiperConnectionState) {
        switch state {
        case .connected:
            print("Did connect swiper")
            self.swiperStatusLabel.text = "Connected"
            self.connectButton.isEnabled = false
            if self.communicationAlert != nil {
                if self.presentedViewController == self.communicationAlert {
                    self.communicationAlert?.dismiss(animated: true, completion: {
                        self.communicationAlert = nil
                    })
                }
                else {
                    self.communicationAlert = nil
                }
            }
        case .disconnected:
            print("Did disconnect swiper")
            self.swiperStatusLabel.text = "Disconnected"
            self.connectButton.isEnabled = true
            if self.communicationAlert != nil {
                if self.presentedViewController == self.communicationAlert {
                    self.communicationAlert?.dismiss(animated: true, completion: {
                        self.communicationAlert = nil
                    })
                }
                else {
                    self.communicationAlert = nil
                }
            }
        case .configuring:
            print("Swiper is configuring")
            self.swiperStatusLabel.text = "Configuring"
            self.connectButton.isEnabled = false
            self.i_showCommunicationAlertWith(message: "Configuring", cancelable: false)
        case .connecting:
            print("Will Connect Swiper")
            self.swiperStatusLabel.text = "Connecting"
            self.connectButton.isEnabled = false
            self.i_showCommunicationAlertWith(message: "Connecting", cancelable: false)
        case .searching:
            print("Will search for Swiper")
            self.swiperStatusLabel.text = "Searching"
            self.connectButton.isEnabled = false
            self.i_showCommunicationAlertWith(message: "Searching", cancelable: true)
        @unknown default:
            ()
        }
    }
    
    func swiperDidStartCardRead(_ swiper: BMSSwiper) {
        print("Card Read Started")
        self.view.endEditing(true)
        
        if self.alert == nil {
            self.alert = UIAlertController(title: "", message: "", preferredStyle: .alert)
            self.alert?.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (UIAlertAction) in
                self.alert = nil
                self.swiper?.cancelTransaction()
            }))
        }
        
        let delegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if self.swipeOnlySwitch.isOn ||
            delegate.swiperType == .BBPOS {
            self.alert?.message = "Swipe Card"
        }
        
        if self.presentedViewController == nil {
            self.present(self.alert!, animated: true, completion: nil)
        }
        else {
            // Delay until alert is dismissed
            let deadlineTime = DispatchTime.now() + .seconds(1)
            DispatchQueue.main.asyncAfter(deadline: deadlineTime) {
                if self.presentedViewController == nil {
                    self.present(self.alert!, animated: true, completion: nil)
                }
            }
        }
    }
    
    func swiper(_ swiper: BMSSwiper, didGenerateTokenWith account: BMSAccount?, completion: @escaping (() -> Void))
    {
        i_stopActivityIndicator()
        
        if self.alert != nil
        {
            self.alert?.dismiss(animated: true, completion: {
                self.alert = nil
            })
        }
        else if self.communicationAlert != nil {
            self.communicationAlert?.dismiss(animated: true, completion: {
                self.communicationAlert = nil
            })
        }
        
        if let account = account
        {
            let alert = UIAlertController(title: "Token Generated", message: account.token, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Retry", style: UIAlertAction.Style.default, handler: { (UIAlertAction) in
                completion()
            }))
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertAction.Style.cancel, handler: { (UIAlertAction) in
                self.restartReaderBlock = completion
                self.restartReaderButton.isEnabled = true
            }))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Error", message: "An unknown error", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Retry", style: UIAlertAction.Style.default, handler: { (UIAlertAction) in
                completion()
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: { (UIAlertAction) in
                self.restartReaderBlock = completion
                self.restartReaderButton.isEnabled = true
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func swiper(_ swiper: BMSSwiper, didFailWithError error: Error, completion: @escaping (() -> Void))
    {
        i_stopActivityIndicator()
        
        if self.alert != nil
        {
            self.alert?.dismiss(animated: true, completion: {
                self.alert = nil
            })
        }
        else if self.communicationAlert != nil {
            self.communicationAlert?.dismiss(animated: true, completion: {
                self.communicationAlert = nil
            })
        }
        
        
        var message = String.init(format: "An error occured: \n%@", error.localizedDescription)
        
        if let firmwareVersion = (error as NSError).userInfo["firmwareVersion"] as? String {
            message.append("\n\n" + firmwareVersion)
        }
        
        let controller = UIAlertController(title: "", message: message, preferredStyle: .alert)
        controller.addAction(UIAlertAction(title: "Retry", style: .destructive, handler: { (_) in
            completion()
        }))
        controller.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: { (UIAlertAction) in
            self.restartReaderBlock = completion
            self.restartReaderButton.isEnabled = true
        }))
        present(controller, animated: true, completion: nil)
    }
    
    func swiper(_ swiper: BMSSwiperController!, foundDevices devices: [Any]!) {
        
    }
    
    func swiper(_ swiper: BMSSwiperController!, displayMessage message: String!, canCancel cancelable: Bool) {
        if self.alert == nil {
            self.alert = UIAlertController.init(title: "", message: "", preferredStyle: UIAlertController.Style.alert)
        }
        
        self.alert?.message = message
        
        if cancelable &&
            self.alert?.actions.count == 0
        {
            self.alert?.addAction(UIAlertAction.init(title: "Cancel", style: UIAlertAction.Style.cancel, handler: { (UIAlertAction) in
                self.alert = nil
                self.swiper?.cancelTransaction()
            }))
        }
        else if !cancelable &&
            (self.alert?.actions.count)! > 0
        {
            for action in (self.alert?.actions)!
            {
                action.isEnabled = false;
            }
        }
        
        if self.presentedViewController == nil {
            self.present(self.alert!, animated: true, completion: nil)
        }
        else if self.presentedViewController == self.communicationAlert {
            self.presentedViewController!.dismiss(animated: false, completion: {
                self.present(self.alert!, animated: true, completion: nil)
            })
        }
    }
    
    func swiper(_ swiper: BMSSwiperController!, configurationProgress progress: Float) {
        self.i_showCommunicationAlertWith(message: String.init(format: "Configuring: %.0f%%", progress*100), cancelable: false)
    }
    
    func swiper(_ swiper: BMSSwiper!, didRead card: BMSNonPaymentCard!, completion: (() -> Void)!) {
        var message:String
        
        if card.isKind(of: BMSLicense.classForCoder()) {
            let license = card as! BMSLicense
            message = String.init(format: "Name: %@\nAddress: %@ %@ %@, %@\n DL#: %@\nDOB: %@\nExpires: %@", license.name,license.address,license.city,license.state,license.postal,license.dln,license.birthday.description,license.expiration.description)
        }
        else {
            message = String.init(format: "Track1: %@\nTrack2: %@\n Track3: %@",card.track1,card.track2,card.track3 )
        }
        
        self.i_stopActivityIndicator()
        
        if self.alert != nil {
            self.alert?.dismiss(animated: true, completion: {
                self.alert = nil
            })
        }
        else if self.communicationAlert != nil {
            self.communicationAlert?.dismiss(animated: true, completion: {
                self.communicationAlert = nil
            })
        }
        
        let alertController = UIAlertController.init(title: "", message: message, preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction.init(title: "Retry", style: .destructive, handler: { (UIAlertAction) in
            completion()
        }))
        
        alertController.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: { (UIAlertAction) in
            self.restartReaderBlock = completion
            self.restartReaderButton.isEnabled = true
        }))
        
        self.present(alertController, animated: true, completion: nil)
    }
}

//
//  SwiperConfigurationViewController.swift
//  BMSSampleApp
//
//  Created by Nick Rimer on 3/14/19.
//

import UIKit
import BoltMobileSDK

class SwiperConfigurationViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, BMSSwiperControllerDelegate {

    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    
    var swiper: BMSSwiperController?
    var foundDevices: [BMSDevice]?
    var tempDevice: BMSDevice?
    
    var alert: UIAlertController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        let delegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
        
        if self.segmentedControl.selectedSegmentIndex == 0 {
            delegate.swiperType = BMSSwiperType.BBPOS
            delegate.device = nil;
        }
        
        self.swiper?.releaseDevice()
        self.swiper = nil
        
        super.viewWillDisappear(animated)
    }

    @IBAction func segmentedControllerValueChanged(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 1 {
            self.swiper?.releaseDevice()
            self.swiper = nil
            
            swiper = BMSSwiperController.init(delegate: self, swiper: BMSSwiperType.VP3300, loggingEnabled: true)
            swiper?.findDevices()
        }
        else if sender.selectedSegmentIndex == 2 {
            self.swiper?.releaseDevice()
            self.swiper = nil
            
            swiper = BMSSwiperController.init(delegate: self, swiper: BMSSwiperType.VP3600, loggingEnabled: true)
            swiper?.findDevices()
        }
        else
        {
            self.swiper?.cancelFindDevices()
            self.foundDevices = nil
        }
        
        self.tableView.reloadData()
    }
    
    // MARK: - TableView Delegate -
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if self.segmentedControl.selectedSegmentIndex == 0
        {
            return 0
        }
        else
        {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.foundDevices?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") ?? UITableViewCell.init(style: UITableViewCell.CellStyle.default, reuseIdentifier: "cell")
        
        cell.textLabel?.text = self.foundDevices![indexPath.row].name
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.swiper?.cancelFindDevices()
        
        self.tempDevice = self.foundDevices![indexPath.row]
        self.swiper?.connect(toDevice: self.tempDevice?.uuid, mode: .swipe)
        
        self.alert = UIAlertController(title: "", message: "Connecting", preferredStyle: .alert)
        
        self.present(self.alert!, animated: true, completion: nil)
    }
    
    // MARK: - Swiper Delegate -
    
    func swiper(_ swiper: BMSSwiper, connectionStateHasChanged state: BMSSwiperConnectionState) {
        switch state {
        case .connected:
            print("Did connect swiper")
        case .disconnected:
            print("Did disconnect swiper")
        case.connecting:
            print("Swiper is connecting")
        case .configuring:
            print("Swiper is configuring")
        case .searching:
            print("Swiper is searching")
        @unknown default:
            print("Unknown state")
        }
    }
    
    func swiperDidStartCardRead(_ swiper: BMSSwiper) {
        let deadlineTime = DispatchTime.now() + .seconds(2)
        DispatchQueue.main.asyncAfter(deadline: deadlineTime) {
            self.swiper?.cancelTransaction()
        }
    }
    
    func swiper(_ swiper: BMSSwiper, didGenerateTokenWith account: BMSAccount?, completion: @escaping (() -> Void)) {
        
    }
    
    func swiper(_ swiper: BMSSwiper, didFailWithError error: Error, completion: @escaping () -> Void) {
        
        // If we connected to the device, we canceled the transaction and should save the device
        if (error as NSError).domain == BMSSwiperErrorDomain &&
            (error as NSError).code == BMSSwiperError.canceledTransaction.rawValue {
            
            let delegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
            
            delegate.swiperType = self.segmentedControl.selectedSegmentIndex == 1 ? BMSSwiperType.VP3300:BMSSwiperType.VP3600
            delegate.device = self.tempDevice
            
            if self.alert != nil {
                self.alert?.dismiss(animated: true, completion: {
                    self.alert = nil
                    self.navigationController?.popViewController(animated: true)
                })
            }
            else {
                self.navigationController?.popViewController(animated: true)
            }
            return
        }
        
        var message = String.init(format: "An error occured: \n%@", error.localizedDescription)
        
        if let firmwareVersion = (error as NSError).userInfo["firmwareVersion"] as? String {
            message.append("\n\n" + firmwareVersion)
        }
        
        let controller = UIAlertController(title: "", message: message, preferredStyle: .alert)
        controller.addAction(UIAlertAction(title: "OK", style: .destructive, handler: nil))
        controller.addAction(UIAlertAction(title: "RETRY", style: .destructive, handler: { (UIAlertAction) in
            completion()
        }))
        
        if self.alert != nil {
            self.alert?.dismiss(animated: true, completion: {
                self.alert = nil
                self.present(controller, animated: true, completion: nil)
            })
        }
        else {
            present(controller, animated: true, completion: nil)
        }
    }
    
    func swiper(_ swiper: BMSSwiperController!, foundDevices devices: [Any]!) {
        self.foundDevices = devices as? [BMSDevice]
        self.tableView.reloadData()
    }
    
    func swiper(_ swiper: BMSSwiperController!, displayMessage message: String!, canCancel cancelable: Bool)
    {
    }
    
    func swiper(_ swiper: BMSSwiperController!, configurationProgress progress: Float) {
        self.alert?.message = String.init(format: "Configuring: %.0f%%", progress*100)
    }
}
